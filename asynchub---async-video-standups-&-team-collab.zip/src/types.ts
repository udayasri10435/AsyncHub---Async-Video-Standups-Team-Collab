export interface User {
  id: string;
  name: string;
  handle: string;
  role: string;
  avatar: string;
  timezone: string;
  timezoneOffset: number; // UTC offset in hours e.g. -7, +1, +9
  city: string;
  status: 'online' | 'recording' | 'focus' | 'offline';
}

export interface TranscriptEntry {
  id: string;
  time: number; // in seconds
  speaker: string;
  text: string;
}

export interface TimelineReaction {
  id: string;
  time: number; // timestamp in seconds where reaction was dropped
  emoji: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  createdAt: string;
}

export interface ActionItem {
  id: string;
  text: string;
  assigneeName?: string;
  assigneeAvatar?: string;
  done: boolean;
  timestampRef?: number;
}

export interface VideoSummary {
  keyTakeaways: string[];
  actionItems: ActionItem[];
  blockers: string[];
  standupBullets?: {
    yesterday: string[];
    today: string[];
    blockers: string[];
  };
}

export interface VideoReply {
  id: string;
  videoId: string;
  author: User;
  createdAt: string;
  type: 'video' | 'audio' | 'text';
  content?: string; // for text reply
  videoUrl?: string; // for video reply
  audioUrl?: string; // for voice memo
  duration?: number;
  timestampRef?: number; // references specific second in main video, e.g. 0:42
  reactions: Record<string, string[]>; // emoji -> userIds
}

export interface StandupVideo {
  id: string;
  title: string;
  description: string;
  channelId: string;
  author: User;
  createdAt: string;
  duration: number; // in seconds
  videoUrl: string;
  thumbnailUrl: string;
  videoType: 'daily_standup' | 'feature_demo' | 'blocker' | 'design_critique' | 'announcement';
  promptBullets: {
    yesterday: string[];
    today: string[];
    blockers: string[];
  };
  transcript: TranscriptEntry[];
  summary: VideoSummary;
  timelineReactions: TimelineReaction[];
  replies: VideoReply[];
  viewsCount: number;
  viewedByUserIds: string[];
  tags: string[];
}

export interface Channel {
  id: string;
  name: string;
  slug: string;
  description: string;
  iconName: string;
  isPrivate: boolean;
  memberCount: number;
  cadence: 'Daily (9 AM local)' | 'Twice weekly' | 'As needed' | 'Weekly review';
  unreadCount?: number;
}

export interface SearchResult {
  video: StandupVideo;
  matchedType: 'transcript' | 'title' | 'action_item' | 'bullet';
  matchedText: string;
  timestamp?: number;
}

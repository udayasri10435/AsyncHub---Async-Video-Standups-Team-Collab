/**
 * Media generator utilities:
 * 1. Web Audio API live microphone VU visualizer
 * 2. Canvas-based dynamic video stream generator (for mock standup playback)
 * 3. Video blob creator for recorded clips
 */

import { StandupVideo } from '../types';

export interface MicAudioMeter {
  analyser: AnalyserNode;
  dataArray: Uint8Array;
  getVolume: () => number;
  stop: () => void;
}

/**
 * Initializes a live microphone volume listener using Web Audio API
 */
export async function createMicAudioMeter(stream: MediaStream): Promise<MicAudioMeter> {
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  const source = audioContext.createMediaStreamSource(stream);
  const analyser = audioContext.createAnalyser();
  analyser.fftSize = 64;
  analyser.smoothingTimeConstant = 0.5;
  source.connect(analyser);

  const dataArray = new Uint8Array(analyser.frequencyBinCount);

  return {
    analyser,
    dataArray,
    getVolume: () => {
      analyser.getByteFrequencyData(dataArray);
      let sum = 0;
      for (let i = 0; i < dataArray.length; i++) {
        sum += dataArray[i];
      }
      const avg = sum / dataArray.length;
      return Math.min(100, Math.round((avg / 128) * 100));
    },
    stop: () => {
      try {
        source.disconnect();
        analyser.disconnect();
        if (audioContext.state !== 'closed') {
          audioContext.close();
        }
      } catch (e) {
        // ignore
      }
    },
  };
}

/**
 * Generates an interactive animated video element canvas stream for sample standups.
 * Renders author portrait / screen share mockup with dynamic speaking waveforms,
 * code line indicators, teleprompter status, and live timecode.
 */
export function drawStandupFrame(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  video: StandupVideo,
  currentTime: number,
  isPlaying: boolean
) {
  // Background gradient: dark sleek slate/indigo
  const bgGrad = ctx.createLinearGradient(0, 0, width, height);
  if (video.videoType === 'blocker') {
    bgGrad.addColorStop(0, '#1e1124');
    bgGrad.addColorStop(1, '#0f0b15');
  } else if (video.videoType === 'design_critique') {
    bgGrad.addColorStop(0, '#0c1a2d');
    bgGrad.addColorStop(1, '#090d16');
  } else {
    bgGrad.addColorStop(0, '#0f172a');
    bgGrad.addColorStop(1, '#020617');
  }
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // Subtle grid backdrop
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
  ctx.lineWidth = 1;
  const gridSize = 40;
  for (let x = 0; x < width; x += gridSize) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let y = 0; y < height; y += gridSize) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  // Simulated screen share workspace area
  const screenX = 30;
  const screenY = 30;
  const screenW = width - 60;
  const screenH = height - 60;

  // Screen frame container
  ctx.fillStyle = 'rgba(15, 23, 42, 0.7)';
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.lineWidth = 1;
  roundRect(ctx, screenX, screenY, screenW, screenH, 12);
  ctx.fill();
  ctx.stroke();

  // Screen top window title bar
  ctx.fillStyle = 'rgba(30, 41, 59, 0.8)';
  ctx.beginPath();
  ctx.roundRect ? ctx.roundRect(screenX, screenY, screenW, 36, [12, 12, 0, 0]) : ctx.rect(screenX, screenY, screenW, 36);
  ctx.fill();

  // Window dots
  ctx.fillStyle = '#ef4444';
  ctx.beginPath();
  ctx.arc(screenX + 20, screenY + 18, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#f59e0b';
  ctx.beginPath();
  ctx.arc(screenX + 36, screenY + 18, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#10b981';
  ctx.beginPath();
  ctx.arc(screenX + 52, screenY + 18, 5, 0, Math.PI * 2);
  ctx.fill();

  // Screen title
  ctx.fillStyle = '#94a3b8';
  ctx.font = '12px "JetBrains Mono", monospace';
  ctx.fillText(`${video.title.slice(0, 48)}... · ${video.author.name} (Async Standup)`, screenX + 70, screenY + 22);

  // Screen content simulation: code editor / design mock
  const contentY = screenY + 48;
  const contentH = screenH - 58;

  // Left sidebar simulation
  ctx.fillStyle = 'rgba(15, 23, 42, 0.5)';
  ctx.fillRect(screenX, contentY, 180, contentH);
  ctx.fillStyle = '#64748b';
  ctx.font = '11px sans-serif';
  ctx.fillText('EXPLORER', screenX + 16, contentY + 22);
  const files = ['src/components/Checkout.tsx', 'src/api/webhooks.ts', 'src/styles/theme.css', 'tests/e2e/pay.spec.ts'];
  files.forEach((f, idx) => {
    ctx.fillStyle = idx === 0 ? '#38bdf8' : '#64748b';
    ctx.fillText(`📄 ${f}`, screenX + 16, contentY + 48 + idx * 24);
  });

  // Main code / document editor simulation
  const editorX = screenX + 190;
  const editorW = screenW - 200;
  ctx.fillStyle = 'rgba(2, 6, 23, 0.4)';
  ctx.fillRect(editorX, contentY, editorW, contentH);

  // Animated code lines / diff preview
  const codeLines = [
    `// Standup update: ${video.author.name} (${video.author.role})`,
    `export async function handleAsyncSync() {`,
    `  const status = await checkStagingHealth();`,
    `  if (!status.ok) throw new Error("Blocker encountered");`,
    `  return { team: "${video.channelId}", latencyMs: 24, verified: true };`,
    `}`,
    ``,
    `// Current timestamp: ${Math.floor(currentTime)}s / ${video.duration}s`,
    `// Spoken update: "${video.transcript.find(t => t.time <= currentTime && currentTime <= t.time + 15)?.text || video.title}"`,
  ];

  ctx.font = '12px "JetBrains Mono", monospace';
  codeLines.forEach((line, idx) => {
    ctx.fillStyle = '#475569';
    ctx.fillText(`${(idx + 1).toString().padStart(2, ' ')}`, editorX + 12, contentY + 30 + idx * 22);

    if (line.startsWith('//')) {
      ctx.fillStyle = '#64748b';
    } else if (line.includes('export') || line.includes('function') || line.includes('return')) {
      ctx.fillStyle = '#c084fc';
    } else if (line.includes('const') || line.includes('if')) {
      ctx.fillStyle = '#38bdf8';
    } else {
      ctx.fillStyle = '#e2e8f0';
    }
    ctx.fillText(line.slice(0, 75), editorX + 40, contentY + 30 + idx * 22);
  });

  // Render floating Loom-style webcam bubble in bottom-left corner of the video
  const bubbleR = 56;
  const bubbleCx = screenX + 80;
  const bubbleCy = screenY + screenH - 80;

  // Pulsing speaking wave ring around bubble if playing
  if (isPlaying) {
    const wave = Math.sin(currentTime * 8) * 6 + 6;
    ctx.strokeStyle = 'rgba(99, 102, 241, 0.5)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(bubbleCx, bubbleCy, bubbleR + wave, 0, Math.PI * 2);
    ctx.stroke();
  }

  // Webcam bubble shadow & border
  ctx.save();
  ctx.beginPath();
  ctx.arc(bubbleCx, bubbleCy, bubbleR, 0, Math.PI * 2);
  ctx.fillStyle = '#1e293b';
  ctx.fill();
  ctx.lineWidth = 3;
  ctx.strokeStyle = '#6366f1';
  ctx.stroke();
  ctx.clip();

  // Draw author gradient background & avatar silhouette
  const avatarGrad = ctx.createLinearGradient(bubbleCx - bubbleR, bubbleCy - bubbleR, bubbleCx + bubbleR, bubbleCy + bubbleR);
  avatarGrad.addColorStop(0, '#4338ca');
  avatarGrad.addColorStop(1, '#1e1b4b');
  ctx.fillStyle = avatarGrad;
  ctx.fillRect(bubbleCx - bubbleR, bubbleCy - bubbleR, bubbleR * 2, bubbleR * 2);

  // Author initials / name
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 22px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const initials = video.author.name.split(' ').map(n => n[0]).join('');
  ctx.fillText(initials, bubbleCx, bubbleCy - 6);

  // Audio wave visualization bar in bubble
  ctx.restore();

  // Mini live microphone waveform beneath bubble
  const micBars = 7;
  const micW = 3;
  const micGap = 3;
  const totalMicW = micBars * (micW + micGap);
  const startMicX = bubbleCx - totalMicW / 2;
  const micY = bubbleCy + bubbleR + 14;

  for (let i = 0; i < micBars; i++) {
    const h = isPlaying ? Math.abs(Math.sin(currentTime * 12 + i * 0.9)) * 14 + 4 : 4;
    ctx.fillStyle = '#6366f1';
    ctx.fillRect(startMicX + i * (micW + micGap), micY - h / 2, micW, h);
  }

  // Live subtitled caption bar at bottom center
  const currentTranscript = video.transcript.slice().reverse().find(t => t.time <= currentTime);
  if (currentTranscript) {
    const captionText = currentTranscript.text;
    ctx.font = '13px sans-serif';
    const textW = ctx.measureText(captionText).width;
    const padX = 18;
    const padY = 8;
    const boxW = Math.min(screenW - 200, textW + padX * 2);
    const boxX = width / 2 - boxW / 2;
    const boxY = height - 76;

    ctx.fillStyle = 'rgba(2, 6, 23, 0.88)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
    ctx.lineWidth = 1;
    roundRect(ctx, boxX, boxY, boxW, 34, 8);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#f8fafc';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(captionText.length > 70 ? captionText.slice(0, 68) + '...' : captionText, width / 2, boxY + 17);
  }
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

/**
 * Creates an audio tone oscillator helper for synthesized standup speech/audio
 */
export function createSynthesizedAudioTrack(ctx: AudioContext, isPlaying: boolean): { gainNode: GainNode; stop: () => void } {
  const osc = ctx.createOscillator();
  const gainNode = ctx.createGain();
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(140, ctx.currentTime);
  gainNode.gain.setValueAtTime(isPlaying ? 0.02 : 0, ctx.currentTime);
  osc.connect(gainNode);
  osc.start();

  return {
    gainNode,
    stop: () => {
      try {
        osc.stop();
        osc.disconnect();
        gainNode.disconnect();
      } catch (e) {
        // ignore
      }
    }
  };
}

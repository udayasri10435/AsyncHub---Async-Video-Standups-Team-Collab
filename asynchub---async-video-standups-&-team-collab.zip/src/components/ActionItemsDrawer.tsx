import React, { useState } from 'react';
import { X, CheckSquare, Square, Clock, ArrowRight, User as UserIcon } from 'lucide-react';
import { StandupVideo, User } from '../types';

interface ActionItemsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  videos: StandupVideo[];
  currentUser: User;
  onToggleActionItem: (videoId: string, actionId: string) => void;
  onSelectVideoAtTime: (video: StandupVideo, timestamp?: number) => void;
}

export const ActionItemsDrawer: React.FC<ActionItemsDrawerProps> = ({
  isOpen,
  onClose,
  videos,
  currentUser,
  onToggleActionItem,
  onSelectVideoAtTime,
}) => {
  const [filterMine, setFilterMine] = useState(false);

  if (!isOpen) return null;

  // Flatten all action items from all standups with video parent reference
  const allTasks = videos.flatMap(v =>
    v.summary.actionItems.map(act => ({
      ...act,
      video: v,
    }))
  );

  const filteredTasks = filterMine
    ? allTasks.filter(
        t =>
          t.assigneeName?.toLowerCase().includes(currentUser.name.toLowerCase()) ||
          t.assigneeName === 'Team'
      )
    : allTasks;

  const completedCount = filteredTasks.filter(t => t.done).length;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-md bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
          <div className="flex items-center gap-2">
            <CheckSquare className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-bold text-slate-100">Team Action Items Hub</h3>
            <span className="text-xs font-mono text-slate-400">
              ({completedCount}/{filteredTasks.length})
            </span>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter bar */}
        <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFilterMine(false)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                !filterMine ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              All Tasks ({allTasks.length})
            </button>
            <button
              onClick={() => setFilterMine(true)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                filterMine ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Assigned to Me
            </button>
          </div>
        </div>

        {/* Task list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 divide-y divide-slate-800/40">
          {filteredTasks.length === 0 ? (
            <div className="text-center py-16 text-slate-500 text-xs">
              No pending action items in this view.
            </div>
          ) : (
            filteredTasks.map(item => (
              <div
                key={`${item.video.id}-${item.id}`}
                className={`pt-2.5 flex items-start gap-3 p-2 rounded-xl border transition-colors ${
                  item.done
                    ? 'bg-slate-950/40 border-slate-800/30 opacity-60'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <button
                  onClick={() => onToggleActionItem(item.video.id, item.id)}
                  className="mt-0.5 text-slate-400 hover:text-indigo-400 transition-colors shrink-0"
                >
                  {item.done ? (
                    <CheckSquare className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Square className="w-4 h-4" />
                  )}
                </button>

                <div className="flex-1 min-w-0">
                  <p
                    className={`text-xs leading-snug ${
                      item.done ? 'line-through text-slate-500' : 'text-slate-200'
                    }`}
                  >
                    {item.text}
                  </p>

                  <div className="mt-2 flex items-center justify-between gap-2 text-[10px] text-slate-400">
                    <div className="flex items-center gap-1.5 truncate">
                      {item.assigneeName && (
                        <span className="font-semibold text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded">
                          @{item.assigneeName}
                        </span>
                      )}
                      <span className="text-slate-500 truncate">{item.video.title}</span>
                    </div>

                    {/* Jump to video button */}
                    <button
                      onClick={() => {
                        onSelectVideoAtTime(item.video, item.timestampRef ?? 0);
                        onClose();
                      }}
                      className="flex items-center gap-1 text-indigo-400 hover:underline shrink-0"
                    >
                      <Clock className="w-2.5 h-2.5" />
                      <span>{formatTime(item.timestampRef ?? 0)}</span>
                      <ArrowRight className="w-2.5 h-2.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState, useMemo, useEffect } from 'react';
import {
  Search,
  X,
  Clock,
  Sparkles,
  ArrowRight,
  MessageSquare,
  CheckSquare,
  FileText,
  User as UserIcon,
} from 'lucide-react';
import { StandupVideo, SearchResult } from '../types';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  videos: StandupVideo[];
  onSelectVideoAtTime: (video: StandupVideo, timestamp?: number) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  videos,
  onSelectVideoAtTime,
}) => {
  const [query, setQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'transcript' | 'action_item' | 'blockers'>('all');

  // Auto-focus search input
  useEffect(() => {
    if (isOpen) {
      setQuery('');
    }
  }, [isOpen]);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const results: SearchResult[] = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];

    const matches: SearchResult[] = [];

    videos.forEach(video => {
      // 1. Search Transcripts
      if (filterType === 'all' || filterType === 'transcript') {
        video.transcript.forEach(entry => {
          if (entry.text.toLowerCase().includes(q)) {
            matches.push({
              video,
              matchedType: 'transcript',
              matchedText: `"${entry.text}"`,
              timestamp: entry.time,
            });
          }
        });
      }

      // 2. Search Title & Description
      if (filterType === 'all') {
        if (video.title.toLowerCase().includes(q) || video.description.toLowerCase().includes(q)) {
          matches.push({
            video,
            matchedType: 'title',
            matchedText: video.title,
            timestamp: 0,
          });
        }
      }

      // 3. Search Action Items
      if (filterType === 'all' || filterType === 'action_item') {
        video.summary.actionItems.forEach(act => {
          if (act.text.toLowerCase().includes(q) || act.assigneeName?.toLowerCase().includes(q)) {
            matches.push({
              video,
              matchedType: 'action_item',
              matchedText: act.text,
              timestamp: act.timestampRef ?? 0,
            });
          }
        });
      }

      // 4. Search Blockers
      if (filterType === 'all' || filterType === 'blockers') {
        video.promptBullets.blockers.forEach(b => {
          if (b.toLowerCase().includes(q)) {
            matches.push({
              video,
              matchedType: 'bullet',
              matchedText: `Blocker: ${b}`,
              timestamp: 0,
            });
          }
        });
      }
    });

    return matches;
  }, [query, filterType, videos]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[75vh]">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-800 flex items-center gap-3 bg-slate-950/70">
          <Search className="w-5 h-5 text-indigo-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search spoken transcripts, topics, action items (e.g. 'ApplePay', 'Kubernetes', 'PgBouncer')..."
            className="flex-1 bg-transparent text-sm text-white placeholder-slate-500 focus:outline-none"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-xs text-slate-500 hover:text-slate-300"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Segmented Buttons */}
        <div className="px-4 py-2 bg-slate-900/60 border-b border-slate-800 flex items-center gap-2 text-xs">
          <span className="text-slate-500 text-[11px]">Filter:</span>
          {(['all', 'transcript', 'action_item', 'blockers'] as const).map(type => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                filterType === type
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {type === 'all'
                ? 'All Content'
                : type === 'transcript'
                ? '🎙️ Spoken Words'
                : type === 'action_item'
                ? '✅ Action Items'
                : '🚨 Blockers'}
            </button>
          ))}
        </div>

        {/* Search Results List */}
        <div className="flex-1 overflow-y-auto p-3 divide-y divide-slate-800/50 space-y-2">
          {!query.trim() ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              <Sparkles className="w-8 h-8 text-indigo-500/50 mx-auto mb-2" />
              <p className="font-semibold text-slate-400">Search spoken transcripts across all standups</p>
              <p className="mt-1 text-slate-500">
                Try searching for: <span className="text-indigo-400">&ldquo;ApplePay&rdquo;</span>,{' '}
                <span className="text-indigo-400">&ldquo;PgBouncer&rdquo;</span>, or{' '}
                <span className="text-indigo-400">&ldquo;Kubernetes&rdquo;</span>
              </p>
            </div>
          ) : results.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              No results found for &ldquo;{query}&rdquo;
            </div>
          ) : (
            results.map((result, idx) => (
              <div
                key={idx}
                onClick={() => {
                  onSelectVideoAtTime(result.video, result.timestamp);
                  onClose();
                }}
                className="pt-2 group flex items-start justify-between gap-4 p-3 rounded-xl hover:bg-slate-800/50 cursor-pointer transition-colors"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <img
                    src={result.video.author.avatar}
                    alt={result.video.author.name}
                    className="w-8 h-8 rounded-full object-cover border border-slate-700 mt-0.5 shrink-0"
                  />

                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-semibold text-slate-200">
                        {result.video.title}
                      </span>
                      <span className="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                        #{result.video.channelId.replace('ch-', '')}
                      </span>
                    </div>

                    {/* Matched Quote */}
                    <p className="text-xs text-slate-300 leading-snug line-clamp-2">
                      {highlightMatches(result.matchedText, query)}
                    </p>

                    <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-500">
                      <span>{result.video.author.name}</span>
                      <span>·</span>
                      <span>{result.matchedType === 'transcript' ? '🎙️ Spoken in video' : '📝 Standup notes'}</span>
                    </div>
                  </div>
                </div>

                {/* Jump to Timestamp Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectVideoAtTime(result.video, result.timestamp);
                    onClose();
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-indigo-300 bg-indigo-950/70 hover:bg-indigo-900/80 border border-indigo-800/60 rounded-lg group-hover:scale-105 transition-all shrink-0"
                >
                  <Clock className="w-3 h-3 text-indigo-400" />
                  <span>Jump to {formatTime(result.timestamp || 0)}</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

function highlightMatches(text: string, query: string) {
  if (!query) return text;
  const parts = text.split(new RegExp(`(${query})`, 'gi'));
  return (
    <>
      {parts.map((p, i) =>
        p.toLowerCase() === query.toLowerCase() ? (
          <mark key={i} className="bg-indigo-500/40 text-indigo-200 px-0.5 rounded font-semibold">
            {p}
          </mark>
        ) : (
          p
        )
      )}
    </>
  );
}

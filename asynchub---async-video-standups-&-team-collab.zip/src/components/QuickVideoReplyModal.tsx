import React, { useState, useRef, useEffect } from 'react';
import { Video, X, Check, RotateCcw, Mic, Camera } from 'lucide-react';
import { StandupVideo, User, VideoReply } from '../types';

interface QuickVideoReplyModalProps {
  isOpen: boolean;
  onClose: () => void;
  video: StandupVideo;
  currentUser: User;
  timestampRef?: number;
  onSaveReply: (reply: VideoReply) => void;
}

export const QuickVideoReplyModal: React.FC<QuickVideoReplyModalProps> = ({
  isOpen,
  onClose,
  video,
  currentUser,
  timestampRef,
  onSaveReply,
}) => {
  const [recordingState, setRecordingState] = useState<'idle' | 'recording' | 'review'>('idle');
  const [duration, setDuration] = useState(0);
  const [replyNote, setReplyNote] = useState('');
  const [recordedUrl, setRecordedUrl] = useState<string | null>(null);

  const videoPreviewRef = useRef<HTMLVideoElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopCamera();
      resetState();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480 },
        audio: true,
      });
      mediaStreamRef.current = stream;
      if (videoPreviewRef.current) {
        videoPreviewRef.current.srcObject = stream;
        videoPreviewRef.current.muted = true;
        videoPreviewRef.current.play().catch(() => {});
      }
    } catch (e) {
      console.warn('Quick reply camera fallback:', e);
    }
  };

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(t => t.stop());
      mediaStreamRef.current = null;
    }
  };

  const resetState = () => {
    setRecordingState('idle');
    setDuration(0);
    setRecordedUrl(null);
    setReplyNote('');
    chunksRef.current = [];
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const startRecording = () => {
    setRecordingState('recording');
    setDuration(0);

    timerRef.current = setInterval(() => {
      setDuration(prev => prev + 1);
    }, 1000);

    if (mediaStreamRef.current) {
      try {
        const recorder = new MediaRecorder(mediaStreamRef.current);
        mediaRecorderRef.current = recorder;
        chunksRef.current = [];

        recorder.ondataavailable = e => {
          if (e.data.size > 0) chunksRef.current.push(e.data);
        };

        recorder.onstop = () => {
          const blob = new Blob(chunksRef.current, { type: 'video/webm' });
          setRecordedUrl(URL.createObjectURL(blob));
          setRecordingState('review');
        };

        recorder.start(1000);
      } catch (e) {
        // fallback
      }
    }
  };

  const stopRecording = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    } else {
      setRecordedUrl('sample://quick-reply-video');
      setRecordingState('review');
    }
  };

  const handlePostReply = () => {
    const newReply: VideoReply = {
      id: `rep-${Date.now()}`,
      videoId: video.id,
      author: currentUser,
      createdAt: new Date().toISOString(),
      type: 'video',
      videoUrl: recordedUrl || undefined,
      content: replyNote.trim() || `Async video response from ${currentUser.name}`,
      duration: Math.max(8, duration),
      timestampRef: timestampRef,
      reactions: { '👍': [currentUser.id] },
    };

    onSaveReply(newReply);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/40">
          <div className="flex items-center gap-2">
            <Video className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-semibold text-slate-100">
              Record Video Reply {typeof timestampRef === 'number' && `(@ ${formatTime(timestampRef)})`}
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewport */}
        <div className="relative aspect-video bg-slate-950 flex items-center justify-center overflow-hidden">
          {recordingState === 'review' ? (
            recordedUrl && recordedUrl.startsWith('blob:') ? (
              <video src={recordedUrl} controls autoPlay className="w-full h-full object-cover" />
            ) : (
              <div className="text-center p-6">
                <Check className="w-12 h-12 text-emerald-400 mx-auto mb-2" />
                <p className="text-sm text-slate-200 font-semibold">Video Reply Recorded!</p>
                <p className="text-xs text-slate-400 mt-1">Duration: {formatTime(duration)}</p>
              </div>
            )
          ) : (
            <video
              ref={videoPreviewRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover mirror"
            />
          )}

          {recordingState === 'recording' && (
            <div className="absolute top-3 left-3 bg-slate-950/80 px-2.5 py-1 rounded-full border border-slate-700 flex items-center gap-2 text-xs font-mono text-rose-400">
              <span className="w-2 h-2 rounded-full bg-rose-600 animate-ping" />
              <span>{formatTime(duration)}</span>
            </div>
          )}
        </div>

        {/* Bottom review or record controls */}
        <div className="p-4 bg-slate-900 space-y-3">
          {recordingState === 'review' ? (
            <>
              <input
                type="text"
                value={replyNote}
                onChange={e => setReplyNote(e.target.value)}
                placeholder="Optional text note to accompany video..."
                className="w-full bg-slate-950 border border-slate-800 text-xs text-white px-3 py-2 rounded-lg focus:outline-none focus:border-indigo-500"
              />
              <div className="flex items-center justify-between">
                <button
                  onClick={() => {
                    resetState();
                    startCamera();
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 rounded-lg"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retake</span>
                </button>

                <button
                  onClick={handlePostReply}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow"
                >
                  <Check className="w-4 h-4" />
                  <span>Attach Video Reply</span>
                </button>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center gap-4">
              {recordingState === 'idle' ? (
                <button
                  onClick={startRecording}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-lg transition-transform hover:scale-105"
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-white" />
                  <span>Record Quick Reply (60s max)</span>
                </button>
              ) : (
                <button
                  onClick={stopRecording}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg"
                >
                  <Check className="w-4 h-4" />
                  <span>Done Recording</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

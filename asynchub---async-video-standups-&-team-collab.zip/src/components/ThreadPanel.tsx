import React, { useState } from 'react';
import {
  Send,
  Video,
  Mic,
  Smile,
  Clock,
  Play,
  RotateCcw,
  Check,
  User as UserIcon,
} from 'lucide-react';
import { StandupVideo, VideoReply, User } from '../types';

interface ThreadPanelProps {
  video: StandupVideo;
  currentUser: User;
  currentTime: number;
  onSeek: (time: number) => void;
  onAddTextReply: (text: string, timestampRef?: number) => void;
  onOpenQuickVideoReply: (timestampRef?: number) => void;
  onToggleReplyReaction: (replyId: string, emoji: string) => void;
}

export const ThreadPanel: React.FC<ThreadPanelProps> = ({
  video,
  currentUser,
  currentTime,
  onSeek,
  onAddTextReply,
  onOpenQuickVideoReply,
  onToggleReplyReaction,
}) => {
  const [replyText, setReplyText] = useState('');
  const [includeTimestamp, setIncludeTimestamp] = useState(true);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim()) return;
    onAddTextReply(
      replyText.trim(),
      includeTimestamp ? Math.floor(currentTime) : undefined
    );
    setReplyText('');
  };

  const formatRelativeTime = (isoString: string) => {
    const diffMs = Date.now() - new Date(isoString).getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    if (diffMins < 1) return 'just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${Math.floor(diffHours / 24)}d ago`;
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/60 rounded-xl border border-slate-800/80 overflow-hidden">
      {/* Thread Header */}
      <div className="p-3 bg-slate-900/80 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-200">Thread Replies</span>
          <span className="text-[11px] font-mono text-slate-400">({video.replies.length})</span>
        </div>

        <button
          onClick={() => onOpenQuickVideoReply(Math.floor(currentTime))}
          className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm transition-all"
        >
          <Video className="w-3.5 h-3.5" />
          <span>Record Video Reply</span>
        </button>
      </div>

      {/* Replies List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {video.replies.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-xs">
            <p className="font-medium text-slate-400 mb-1">No async replies yet</p>
            <p>Leave a text comment, audio snippet, or record a quick video reply.</p>
          </div>
        ) : (
          video.replies.map(reply => {
            const isMe = reply.author.id === currentUser.id;
            return (
              <div
                key={reply.id}
                className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/50 border border-slate-800/70 hover:border-slate-700/60 transition-colors"
              >
                <img
                  src={reply.author.avatar}
                  alt={reply.author.name}
                  className="w-8 h-8 rounded-full object-cover border border-slate-700 shrink-0"
                />

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-slate-200">
                        {reply.author.name}
                      </span>
                      <span className="text-[10px] text-slate-500">{reply.author.city}</span>
                    </div>

                    <div className="flex items-center gap-2 text-[10px] text-slate-500">
                      {typeof reply.timestampRef === 'number' && (
                        <button
                          onClick={() => onSeek(reply.timestampRef!)}
                          className="flex items-center gap-1 text-indigo-400 bg-indigo-950/60 border border-indigo-800/50 px-1.5 py-0.5 rounded font-mono hover:bg-indigo-900/60 transition-colors"
                          title="Jump video to referenced moment"
                        >
                          <Clock className="w-2.5 h-2.5" />
                          <span>@{formatTime(reply.timestampRef)}</span>
                        </button>
                      )}
                      <span>{formatRelativeTime(reply.createdAt)}</span>
                    </div>
                  </div>

                  {/* Reply Content */}
                  {reply.type === 'text' && (
                    <p className="text-xs text-slate-300 leading-relaxed break-words whitespace-pre-wrap">
                      {reply.content}
                    </p>
                  )}

                  {reply.type === 'video' && (
                    <div className="mt-2 rounded-lg overflow-hidden border border-slate-700 bg-slate-950">
                      <div className="relative aspect-video max-w-xs bg-slate-900 flex items-center justify-center">
                        {reply.videoUrl ? (
                          <video
                            src={reply.videoUrl}
                            controls
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="text-center p-3">
                            <Video className="w-8 h-8 text-indigo-400 mx-auto mb-1" />
                            <span className="text-[11px] text-slate-400">Video Reply</span>
                          </div>
                        )}
                      </div>
                      {reply.content && (
                        <p className="p-2 text-xs text-slate-300">{reply.content}</p>
                      )}
                    </div>
                  )}

                  {reply.type === 'audio' && (
                    <div className="mt-2 flex items-center gap-3 p-2.5 bg-slate-900 rounded-lg border border-slate-800 max-w-xs">
                      <div className="w-8 h-8 rounded-full bg-indigo-600/30 text-indigo-400 flex items-center justify-center shrink-0">
                        <Mic className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                          <span className="font-medium text-slate-300">Voice Note</span>
                          <span className="font-mono">{reply.duration || 20}s</span>
                        </div>
                        {/* Audio wave bars */}
                        <div className="flex items-center gap-0.5 h-3">
                          {[3, 6, 10, 5, 8, 12, 7, 4, 9, 11, 6, 8, 4, 7].map((h, i) => (
                            <span
                              key={i}
                              style={{ height: `${h}px` }}
                              className="w-1 bg-indigo-500 rounded-full"
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Reaction pills */}
                  <div className="mt-2 flex items-center gap-1.5 flex-wrap">
                    {Object.entries(reply.reactions || {}).map(([emoji, users]) => {
                      const userReacted = users.includes(currentUser.id);
                      return (
                        <button
                          key={emoji}
                          onClick={() => onToggleReplyReaction(reply.id, emoji)}
                          className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] border transition-colors ${
                            userReacted
                              ? 'bg-indigo-950/60 border-indigo-700/80 text-indigo-200'
                              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          <span>{emoji}</span>
                          <span className="font-mono text-[10px]">{users.length}</span>
                        </button>
                      );
                    })}

                    {/* Quick emoji reaction add buttons */}
                    {['👍', '🔥', '🙌', '💯'].map(emoji => (
                      <button
                        key={emoji}
                        onClick={() => onToggleReplyReaction(reply.id, emoji)}
                        className="opacity-0 group-hover:opacity-100 hover:opacity-100 text-slate-400 hover:text-white px-1.5 py-0.5 rounded text-xs transition-opacity"
                        title={`React with ${emoji}`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Input area */}
      <form onSubmit={handleSend} className="p-3 bg-slate-900/90 border-t border-slate-800/80">
        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={includeTimestamp}
              onChange={e => setIncludeTimestamp(e.target.checked)}
              className="rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-0"
            />
            <span>Anchor to video timestamp ({formatTime(currentTime)})</span>
          </label>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="text"
            value={replyText}
            onChange={e => setReplyText(e.target.value)}
            placeholder="Type an async reply or feedback..."
            className="flex-1 bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 px-3 py-2 rounded-lg focus:outline-none focus:border-indigo-500 transition-colors"
          />

          <button
            type="button"
            onClick={() => onOpenQuickVideoReply(Math.floor(currentTime))}
            title="Record video reply"
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <Video className="w-4 h-4" />
          </button>

          <button
            type="submit"
            disabled={!replyText.trim()}
            className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};

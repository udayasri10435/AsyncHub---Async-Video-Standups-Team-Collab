import React, { useState } from 'react';
import {
  CheckSquare,
  Square,
  AlertCircle,
  Sparkles,
  Plus,
  Clock,
  CheckCircle2,
  Calendar,
} from 'lucide-react';
import { StandupVideo, ActionItem } from '../types';

interface SummaryPanelProps {
  video: StandupVideo;
  onSeek: (time: number) => void;
  onToggleActionItem: (actionId: string) => void;
  onAddActionItem: (text: string, assigneeName?: string) => void;
  onRegenerateAiSummary?: () => Promise<void>;
  isGeneratingAi?: boolean;
}

export const SummaryPanel: React.FC<SummaryPanelProps> = ({
  video,
  onSeek,
  onToggleActionItem,
  onAddActionItem,
  onRegenerateAiSummary,
  isGeneratingAi = false,
}) => {
  const [newActionText, setNewActionText] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleCreateAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newActionText.trim()) return;
    onAddActionItem(newActionText.trim());
    setNewActionText('');
    setShowAddForm(false);
  };

  const completedCount = video.summary.actionItems.filter(a => a.done).length;
  const totalCount = video.summary.actionItems.length;

  return (
    <div className="flex flex-col h-full bg-slate-900/60 rounded-xl border border-slate-800/80 overflow-hidden divide-y divide-slate-800/60">
      {/* Top Bar with AI Regenerate */}
      <div className="p-3 bg-slate-900/80 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>AI Standup Summary & Tasks</span>
        </div>

        {onRegenerateAiSummary && (
          <button
            onClick={onRegenerateAiSummary}
            disabled={isGeneratingAi}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 transition-colors disabled:opacity-50"
          >
            <Sparkles className={`w-3 h-3 ${isGeneratingAi ? 'animate-spin' : ''}`} />
            <span>{isGeneratingAi ? 'Analyzing...' : 'Refresh AI'}</span>
          </button>
        )}
      </div>

      {/* Main scrollable body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 text-xs">
        {/* Key Takeaways */}
        <div>
          <h4 className="font-semibold text-slate-300 mb-2 uppercase tracking-wider text-[11px] text-slate-400">
            Key Takeaways
          </h4>
          <ul className="space-y-1.5 text-slate-300">
            {video.summary.keyTakeaways.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                <span className="leading-relaxed">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Standup Prompt Bullets (Yesterday / Today / Blockers) */}
        <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/80 space-y-3">
          <div className="flex items-center justify-between text-[11px] font-medium text-slate-400">
            <span>STANDUP NOTES</span>
            <span className="font-mono text-slate-500">{video.author.name}</span>
          </div>

          {/* Yesterday */}
          {video.promptBullets.yesterday?.length > 0 && (
            <div>
              <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1 mb-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                Yesterday:
              </span>
              <ul className="pl-4 space-y-1 text-slate-300">
                {video.promptBullets.yesterday.map((y, idx) => (
                  <li key={idx} className="list-disc list-outside leading-relaxed text-[11px]">{y}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Today */}
          {video.promptBullets.today?.length > 0 && (
            <div>
              <span className="text-[11px] font-semibold text-sky-400 flex items-center gap-1 mb-1">
                <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                Today:
              </span>
              <ul className="pl-4 space-y-1 text-slate-300">
                {video.promptBullets.today.map((t, idx) => (
                  <li key={idx} className="list-disc list-outside leading-relaxed text-[11px]">{t}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Blockers */}
          {video.promptBullets.blockers?.length > 0 && (
            <div>
              <span className="text-[11px] font-semibold text-rose-400 flex items-center gap-1 mb-1">
                <AlertCircle className="w-3 h-3 text-rose-400" />
                Blockers:
              </span>
              <ul className="pl-4 space-y-1 text-rose-200">
                {video.promptBullets.blockers.map((b, idx) => (
                  <li key={idx} className="list-disc list-outside leading-relaxed text-[11px] font-medium">{b}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Action Items Checklist */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <h4 className="font-semibold uppercase tracking-wider text-[11px] text-slate-400">
                Action Items
              </h4>
              {totalCount > 0 && (
                <span className="text-[11px] font-mono text-slate-400">
                  ({completedCount}/{totalCount})
                </span>
              )}
            </div>

            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
            >
              <Plus className="w-3 h-3" />
              <span>Add task</span>
            </button>
          </div>

          {/* Add form */}
          {showAddForm && (
            <form onSubmit={handleCreateAction} className="mb-3 flex items-center gap-2">
              <input
                type="text"
                value={newActionText}
                onChange={e => setNewActionText(e.target.value)}
                placeholder="New action item or follow-up..."
                className="flex-1 bg-slate-950 border border-slate-700 text-xs text-white px-2.5 py-1.5 rounded-lg focus:outline-none focus:border-indigo-500"
                autoFocus
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-lg"
              >
                Add
              </button>
            </form>
          )}

          {/* Action item list */}
          <div className="space-y-1.5">
            {video.summary.actionItems.length === 0 ? (
              <p className="text-slate-500 text-xs italic">No explicit action items assigned yet.</p>
            ) : (
              video.summary.actionItems.map(item => (
                <div
                  key={item.id}
                  className={`p-2 rounded-lg border transition-colors flex items-start gap-2.5 ${
                    item.done
                      ? 'bg-slate-950/40 border-slate-800/40 opacity-60'
                      : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <button
                    onClick={() => onToggleActionItem(item.id)}
                    className="mt-0.5 text-slate-400 hover:text-indigo-400 transition-colors"
                  >
                    {item.done ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>

                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-xs leading-snug ${
                        item.done ? 'line-through text-slate-500' : 'text-slate-200'
                      }`}
                    >
                      {item.text}
                    </p>

                    <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-400">
                      {item.assigneeName && (
                        <span className="font-medium text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded">
                          @{item.assigneeName}
                        </span>
                      )}
                      {typeof item.timestampRef === 'number' && (
                        <button
                          onClick={() => onSeek(item.timestampRef!)}
                          className="flex items-center gap-0.5 text-indigo-400 hover:underline"
                        >
                          <Clock className="w-2.5 h-2.5" />
                          <span>{formatTime(item.timestampRef)}</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

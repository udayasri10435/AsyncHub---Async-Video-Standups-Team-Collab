import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  RotateCcw,
  Sparkles,
  Smile,
  FastForward,
  Copy,
  Check,
} from 'lucide-react';
import { StandupVideo, TimelineReaction } from '../types';
import { drawStandupFrame } from '../utils/mediaGenerator';

interface VideoPlayerProps {
  video: StandupVideo;
  currentTime: number;
  onTimeUpdate: (time: number) => void;
  onAddReaction: (emoji: string, time: number) => void;
  seekToTime?: number | null;
}

const QUICK_EMOJIS = ['🔥', '👍', '💡', '🚀', '❤️', '👏', '👀', '❓'];

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  video,
  currentTime,
  onTimeUpdate,
  onAddReaction,
  seekToTime,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const animationFrameRef = useRef<number | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [volume, setVolume] = useState<number>(0.8);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState<boolean>(false);
  const [floatingEmojis, setFloatingEmojis] = useState<{ id: string; emoji: string; x: number }[]>([]);
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [hoverPosition, setHoverPosition] = useState<number | null>(null);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  const isRealVideo = video.videoUrl && (video.videoUrl.startsWith('blob:') || video.videoUrl.startsWith('http'));

  // Handle external seek requests (e.g. clicking transcript line)
  useEffect(() => {
    if (typeof seekToTime === 'number') {
      if (isRealVideo && videoRef.current) {
        videoRef.current.currentTime = seekToTime;
      }
      onTimeUpdate(seekToTime);
    }
  }, [seekToTime, isRealVideo, onTimeUpdate]);

  // Canvas animation loop for synthesized / sample videos
  useEffect(() => {
    if (isRealVideo) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let lastTimestamp = performance.now();

    const render = (now: number) => {
      const delta = (now - lastTimestamp) / 1000;
      lastTimestamp = now;

      if (isPlaying) {
        const nextTime = currentTime + delta * playbackSpeed;
        if (nextTime >= video.duration) {
          onTimeUpdate(video.duration);
          setIsPlaying(false);
        } else {
          onTimeUpdate(nextTime);
        }
      }

      drawStandupFrame(ctx, canvas.width, canvas.height, video, currentTime, isPlaying);
      animationFrameRef.current = requestAnimationFrame(render);
    };

    animationFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isRealVideo, isPlaying, currentTime, playbackSpeed, video, onTimeUpdate]);

  // Video element playback speed and volume sync for real videos
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = playbackSpeed;
      videoRef.current.volume = isMuted ? 0 : volume;
    }
  }, [playbackSpeed, volume, isMuted]);

  const togglePlay = useCallback(() => {
    if (isRealVideo && videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play().catch(() => {});
      }
    }
    setIsPlaying(prev => !prev);
  }, [isRealVideo, isPlaying]);

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, clickX / rect.width));
    const newTime = percentage * video.duration;

    if (isRealVideo && videoRef.current) {
      videoRef.current.currentTime = newTime;
    }
    onTimeUpdate(newTime);
  };

  const handleTimelineHover = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const hoverX = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, hoverX / rect.width));
    setHoverPosition(percentage * 100);
    setHoverTime(percentage * video.duration);
  };

  const triggerReaction = (emoji: string) => {
    onAddReaction(emoji, Math.floor(currentTime));

    // trigger floating reaction animation
    const id = Math.random().toString();
    const randomX = 30 + Math.random() * 40; // 30% to 70% width
    setFloatingEmojis(prev => [...prev, { id, emoji, x: randomX }]);

    setTimeout(() => {
      setFloatingEmojis(prev => prev.filter(item => item.id !== id));
    }, 1800);
  };

  const copyTimestampLink = () => {
    const formatted = formatTime(currentTime);
    navigator.clipboard?.writeText?.(`${window.location.origin}/#${video.id}?t=${Math.floor(currentTime)}`);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progressPercent = Math.min(100, (currentTime / (video.duration || 1)) * 100);

  return (
    <div
      ref={containerRef}
      className="relative flex flex-col w-full bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl select-none group"
    >
      {/* Video Content Canvas or Video Element */}
      <div className="relative aspect-video w-full bg-slate-950 flex items-center justify-center overflow-hidden">
        {isRealVideo ? (
          <video
            ref={videoRef}
            src={video.videoUrl}
            className="w-full h-full object-cover"
            playsInline
            onTimeUpdate={() => {
              if (videoRef.current) onTimeUpdate(videoRef.current.currentTime);
            }}
            onEnded={() => setIsPlaying(false)}
            onClick={togglePlay}
          />
        ) : (
          <canvas
            ref={canvasRef}
            width={1280}
            height={720}
            className="w-full h-full object-cover cursor-pointer"
            onClick={togglePlay}
          />
        )}

        {/* Floating reaction particle animations */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {floatingEmojis.map(item => (
            <div
              key={item.id}
              style={{ left: `${item.x}%` }}
              className="absolute bottom-16 text-3xl animate-bounce transition-all duration-1000 transform -translate-y-24 opacity-90"
            >
              {item.emoji}
            </div>
          ))}
        </div>

        {/* Big play button overlay when paused */}
        {!isPlaying && (
          <button
            onClick={togglePlay}
            aria-label="Play video"
            className="absolute z-20 w-16 h-16 rounded-full bg-indigo-600/90 text-white flex items-center justify-center shadow-xl backdrop-blur hover:bg-indigo-500 hover:scale-105 transition-transform"
          >
            <Play className="w-8 h-8 ml-1 fill-white" />
          </button>
        )}

        {/* Standup topic tag chip */}
        <div className="absolute top-4 left-4 z-10 flex items-center gap-2">
          <span className="px-2.5 py-1 text-xs font-medium rounded-md bg-slate-900/80 backdrop-blur border border-slate-700/60 text-slate-200">
            {video.videoType === 'daily_standup'
              ? '☀️ Daily Standup'
              : video.videoType === 'blocker'
              ? '🚨 Blocker Alert'
              : video.videoType === 'design_critique'
              ? '🎨 Design Walkthrough'
              : '⚡ Feature Showcase'}
          </span>
          <span className="text-xs text-slate-400 bg-slate-900/60 px-2 py-0.5 rounded backdrop-blur">
            {video.author.city}
          </span>
        </div>

        {/* Quick timestamp share button */}
        <div className="absolute top-4 right-4 z-10">
          <button
            onClick={copyTimestampLink}
            title="Copy share link at current timestamp"
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md bg-slate-900/80 backdrop-blur border border-slate-700/60 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedLink ? 'Copied Link' : `Share @ ${formatTime(currentTime)}`}</span>
          </button>
        </div>
      </div>

      {/* Scrubber & Player Controls Bar */}
      <div className="bg-slate-900/95 backdrop-blur border-t border-slate-800 p-3 flex flex-col gap-2">
        {/* Timeline Scrubber Container */}
        <div
          className="relative w-full h-4 cursor-pointer flex items-center"
          onClick={handleSeek}
          onMouseMove={handleTimelineHover}
          onMouseLeave={() => {
            setHoverTime(null);
            setHoverPosition(null);
          }}
        >
          {/* Background rail */}
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden relative">
            {/* Played progress */}
            <div
              className="h-full bg-indigo-500 rounded-full transition-all duration-75"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Hover preview tooltip */}
          {hoverTime !== null && hoverPosition !== null && (
            <div
              className="absolute -top-7 transform -translate-x-1/2 bg-slate-950 text-slate-200 border border-slate-700 px-2 py-0.5 rounded text-[11px] font-mono pointer-events-none z-30 shadow-lg"
              style={{ left: `${hoverPosition}%` }}
            >
              {formatTime(hoverTime)}
            </div>
          )}

          {/* Timeline Reactions Pins */}
          {video.timelineReactions.map(reaction => {
            const reactionPercent = Math.min(100, Math.max(0, (reaction.time / video.duration) * 100));
            return (
              <button
                key={reaction.id}
                onClick={(e) => {
                  e.stopPropagation();
                  onTimeUpdate(reaction.time);
                }}
                title={`${reaction.emoji} by ${reaction.userName} at ${formatTime(reaction.time)}`}
                style={{ left: `${reactionPercent}%` }}
                className="absolute transform -translate-x-1/2 -top-1 w-5 h-5 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center text-[11px] shadow hover:scale-125 transition-transform z-20"
              >
                {reaction.emoji}
              </button>
            );
          })}

          {/* Scrubber knob */}
          <div
            className="absolute w-3.5 h-3.5 bg-white rounded-full shadow border-2 border-indigo-600 transform -translate-x-1/2 pointer-events-none transition-all duration-75"
            style={{ left: `${progressPercent}%` }}
          />
        </div>

        {/* Lower Row Controls */}
        <div className="flex items-center justify-between gap-4 text-slate-300">
          {/* Left: Play/Pause, Time, Jump */}
          <div className="flex items-center gap-3">
            <button
              onClick={togglePlay}
              className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-200 hover:text-white transition-colors"
              title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            </button>

            <button
              onClick={() => onTimeUpdate(Math.max(0, currentTime - 5))}
              className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
              title="Back 5s"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            <span className="text-xs font-mono text-slate-400">
              <span className="text-slate-200 font-semibold">{formatTime(currentTime)}</span> / {formatTime(video.duration)}
            </span>
          </div>

          {/* Center: Live Timestamp Emoji Dropper */}
          <div className="relative flex items-center gap-1 bg-slate-950/70 border border-slate-800 rounded-lg p-1">
            <span className="text-[11px] font-medium text-slate-400 px-1 hidden sm:inline">React:</span>
            {QUICK_EMOJIS.slice(0, 5).map(emoji => (
              <button
                key={emoji}
                onClick={() => triggerReaction(emoji)}
                className="w-7 h-7 flex items-center justify-center rounded hover:bg-slate-800 hover:scale-110 active:scale-95 text-sm transition-transform"
                title={`Drop ${emoji} at ${formatTime(currentTime)}`}
              >
                {emoji}
              </button>
            ))}
            <button
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              className="w-7 h-7 flex items-center justify-center rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
              title="More reactions"
            >
              <Smile className="w-3.5 h-3.5" />
            </button>

            {/* Extended emoji popup */}
            {showEmojiPicker && (
              <div className="absolute bottom-10 left-0 bg-slate-900 border border-slate-700 rounded-xl p-2 shadow-2xl flex gap-1 z-30 backdrop-blur">
                {QUICK_EMOJIS.map(emoji => (
                  <button
                    key={emoji}
                    onClick={() => {
                      triggerReaction(emoji);
                      setShowEmojiPicker(false);
                    }}
                    className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-800 text-base transition-transform hover:scale-110"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right: Speed, Volume, Fullscreen */}
          <div className="flex items-center gap-2">
            {/* Playback speed selector */}
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5">
              {[1, 1.25, 1.5, 2].map(speed => (
                <button
                  key={speed}
                  onClick={() => setPlaybackSpeed(speed)}
                  className={`px-2 py-0.5 text-[11px] font-mono rounded transition-colors ${
                    playbackSpeed === speed
                      ? 'bg-indigo-600 text-white font-medium shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {speed}x
                </button>
              ))}
            </div>

            {/* Volume toggle */}
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* Fullscreen */}
            <button
              onClick={toggleFullscreen}
              className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Video,
  Monitor,
  Mic,
  MicOff,
  Square,
  Play,
  RotateCcw,
  Sparkles,
  X,
  Check,
  Camera,
  Layers,
  FileText,
  Sliders,
  ChevronDown,
  Clock,
  AlertCircle,
} from 'lucide-react';
import { Channel, StandupVideo, User } from '../types';
import { createMicAudioMeter, MicAudioMeter } from '../utils/mediaGenerator';

interface RecorderModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  channels: Channel[];
  selectedChannelId: string;
  onSaveVideo: (newVideo: StandupVideo) => void;
}

type RecordMode = 'camera' | 'screen_cam' | 'screen_only' | 'simulation';

export const RecorderModal: React.FC<RecorderModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  channels,
  selectedChannelId,
  onSaveVideo,
}) => {
  const [mode, setMode] = useState<RecordMode>('camera');
  const [recordingState, setRecordingState] = useState<'idle' | 'countdown' | 'recording' | 'paused' | 'review'>('idle');
  const [countdown, setCountdown] = useState<number>(3);
  const [duration, setDuration] = useState<number>(0);
  const [micLevel, setMicLevel] = useState<number>(0);
  const [hasMic, setHasMic] = useState<boolean>(true);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Teleprompter / Notes drawer state
  const [showTeleprompter, setShowTeleprompter] = useState<boolean>(true);
  const [teleprompterYesterday, setTeleprompterYesterday] = useState<string>(
    'Shipped payment retry logic\nFixed checkout sheet dismiss on iOS'
  );
  const [teleprompterToday, setTeleprompterToday] = useState<string>(
    'Integrating ApplePay one-touch tokens\nPairing with Marcus on API contract'
  );
  const [teleprompterBlockers, setTeleprompterBlockers] = useState<string>(
    'Awaiting sandbox credentials update'
  );

  // Post recording review state
  const [title, setTitle] = useState<string>('Daily Standup - ' + new Date().toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' }));
  const [channelId, setChannelId] = useState<string>(selectedChannelId);
  const [recordedBlobUrl, setRecordedBlobUrl] = useState<string | null>(null);
  const [isAiTranscribing, setIsAiTranscribing] = useState<boolean>(false);
  const [generatedTranscriptPreview, setGeneratedTranscriptPreview] = useState<string>('');

  const liveVideoRef = useRef<HTMLVideoElement>(null);
  const reviewVideoRef = useRef<HTMLVideoElement>(null);
  const compositeCanvasRef = useRef<HTMLCanvasElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<any>(null);
  const micMeterRef = useRef<MicAudioMeter | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Initialize preview stream when modal opens or mode changes
  const initPreview = useCallback(async () => {
    setCameraError(null);
    stopAllStreams();

    if (mode === 'simulation') {
      // In simulation mode, no hardware permissions required
      return;
    }

    try {
      if (mode === 'camera') {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' },
          audio: true,
        });
        mediaStreamRef.current = stream;
        if (liveVideoRef.current) {
          liveVideoRef.current.srcObject = stream;
          liveVideoRef.current.muted = true;
          liveVideoRef.current.play().catch(() => {});
        }

        // Attach mic meter
        const meter = await createMicAudioMeter(stream);
        micMeterRef.current = meter;
      } else if (mode === 'screen_cam' || mode === 'screen_only') {
        try {
          const screenStream = await navigator.mediaDevices.getDisplayMedia({
            video: true,
            audio: true,
          });
          screenStreamRef.current = screenStream;

          if (mode === 'screen_cam') {
            const camStream = await navigator.mediaDevices.getUserMedia({
              video: { width: 320, height: 240 },
              audio: true,
            });
            mediaStreamRef.current = camStream;
            const meter = await createMicAudioMeter(camStream);
            micMeterRef.current = meter;
          }

          if (liveVideoRef.current) {
            liveVideoRef.current.srcObject = screenStream;
            liveVideoRef.current.muted = true;
            liveVideoRef.current.play().catch(() => {});
          }
        } catch (e: any) {
          setCameraError('Screen share permission was cancelled or not granted.');
          setMode('simulation');
        }
      }
    } catch (err: any) {
      console.warn('Camera/mic access error:', err);
      setCameraError('Camera access not granted or not available. Switched to Studio Simulator mode.');
      setMode('simulation');
    }
  }, [mode]);

  useEffect(() => {
    if (isOpen) {
      initPreview();
    } else {
      stopAllStreams();
      resetRecordingState();
    }

    return () => {
      stopAllStreams();
    };
  }, [isOpen, initPreview]);

  // Audio level polling loop
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      if (micMeterRef.current) {
        setMicLevel(micMeterRef.current.getVolume());
      } else if (recordingState === 'recording') {
        // simulate mic activity for simulation mode
        setMicLevel(Math.floor(Math.random() * 45) + 20);
      } else {
        setMicLevel(0);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [isOpen, recordingState]);

  const stopAllStreams = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(t => t.stop());
      mediaStreamRef.current = null;
    }
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(t => t.stop());
      screenStreamRef.current = null;
    }
    if (micMeterRef.current) {
      micMeterRef.current.stop();
      micMeterRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
  };

  const resetRecordingState = () => {
    setRecordingState('idle');
    setDuration(0);
    setCountdown(3);
    setRecordedBlobUrl(null);
    recordedChunksRef.current = [];
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
  };

  const startCountdown = () => {
    setRecordingState('countdown');
    setCountdown(3);

    let count = 3;
    const countdownTimer = setInterval(() => {
      count -= 1;
      if (count <= 0) {
        clearInterval(countdownTimer);
        startActualRecording();
      } else {
        setCountdown(count);
      }
    }, 1000);
  };

  const startActualRecording = () => {
    setRecordingState('recording');
    setDuration(0);

    timerIntervalRef.current = setInterval(() => {
      setDuration(prev => prev + 1);
    }, 1000);

    // If we have actual mediaStream
    if (mediaStreamRef.current || screenStreamRef.current) {
      try {
        const streamToRecord = mediaStreamRef.current || screenStreamRef.current!;
        const mediaRecorder = new MediaRecorder(streamToRecord, {
          mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
            ? 'video/webm;codecs=vp9'
            : 'video/webm',
        });
        mediaRecorderRef.current = mediaRecorder;
        recordedChunksRef.current = [];

        mediaRecorder.ondataavailable = e => {
          if (e.data.size > 0) {
            recordedChunksRef.current.push(e.data);
          }
        };

        mediaRecorder.onstop = () => {
          const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          setRecordedBlobUrl(url);
          setRecordingState('review');
        };

        mediaRecorder.start(1000);
      } catch (e) {
        console.error('Failed to start MediaRecorder:', e);
      }
    }
  };

  const pauseRecording = () => {
    if (recordingState === 'recording') {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.pause();
      }
      clearInterval(timerIntervalRef.current);
      setRecordingState('paused');
    } else if (recordingState === 'paused') {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'paused') {
        mediaRecorderRef.current.resume();
      }
      timerIntervalRef.current = setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);
      setRecordingState('recording');
    }
  };

  const finishRecording = () => {
    clearInterval(timerIntervalRef.current);

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    } else {
      // Simulation mode review
      setRecordedBlobUrl('sample://user-recorded-clip');
      setRecordingState('review');
    }
  };

  const handleRetake = () => {
    resetRecordingState();
    initPreview();
  };

  const handlePublish = async () => {
    const yesterdayBullets = teleprompterYesterday.split('\n').filter(s => s.trim());
    const todayBullets = teleprompterToday.split('\n').filter(s => s.trim());
    const blockerBullets = teleprompterBlockers.split('\n').filter(s => s.trim());

    const finalDuration = Math.max(15, duration);

    // Build synthesized transcript based on the notes & speech
    const transcript = [
      { id: 'tr-user-1', time: 0, speaker: currentUser.name, text: `Hello team, here is my async standup update for ${title}.` },
      { id: 'tr-user-2', time: 6, speaker: currentUser.name, text: `Yesterday: ${yesterdayBullets[0] || 'Continued core feature development.'}` },
      { id: 'tr-user-3', time: 18, speaker: currentUser.name, text: `Today I am focused on: ${todayBullets[0] || 'Key deliverables and code reviews.'}` },
    ];
    if (blockerBullets.length > 0) {
      transcript.push({
        id: 'tr-user-4',
        time: 30,
        speaker: currentUser.name,
        text: `Regarding blockers: ${blockerBullets.join(', ')}`,
      });
    }

    const newVideo: StandupVideo = {
      id: `vid-${Date.now()}`,
      title: title.trim() || 'Daily Standup Update',
      description: `Async standup by ${currentUser.name}. Topics: ${todayBullets.join(', ')}`,
      channelId: channelId,
      author: currentUser,
      createdAt: new Date().toISOString(),
      duration: finalDuration,
      videoUrl: recordedBlobUrl || 'sample://user-recorded-clip',
      thumbnailUrl: currentUser.avatar,
      videoType: blockerBullets.length > 0 ? 'blocker' : 'daily_standup',
      promptBullets: {
        yesterday: yesterdayBullets,
        today: todayBullets,
        blockers: blockerBullets,
      },
      transcript,
      summary: {
        keyTakeaways: [
          `Accomplishments: ${yesterdayBullets.join('; ') || 'Core sprint work'}.`,
          `Current priority: ${todayBullets.join('; ') || 'Product engineering'}.`,
          blockerBullets.length ? `Blockers highlighted: ${blockerBullets.join('; ')}` : 'No blocking issues.',
        ],
        actionItems: todayBullets.map((t, idx) => ({
          id: `act-new-${idx}`,
          text: t,
          assigneeName: currentUser.name,
          done: false,
          timestampRef: 18,
        })),
        blockers: blockerBullets,
      },
      timelineReactions: [],
      replies: [],
      viewsCount: 1,
      viewedByUserIds: [currentUser.id],
      tags: ['Standup', currentUser.role.split(' ')[0]],
    };

    onSaveVideo(newVideo);
    onClose();
  };

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl h-[90vh] max-h-[820px] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Studio Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100">
                {recordingState === 'review' ? 'Review & Publish Standup' : 'Async Recording Studio'}
              </h2>
              <p className="text-[11px] text-slate-400">
                {recordingState === 'review'
                  ? 'Verify your video, edit standup notes, and broadcast to channel'
                  : 'Record high-impact async standups with built-in teleprompter notes'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowTeleprompter(!showTeleprompter)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                showTeleprompter
                  ? 'bg-indigo-950/80 border-indigo-700 text-indigo-200'
                  : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Teleprompter</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Studio Main Workspace: Viewport + Teleprompter Notes */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left/Center: Video Viewport & Studio Canvas */}
          <div className="flex-1 flex flex-col bg-slate-950 p-6 overflow-y-auto">
            {cameraError && (
              <div className="mb-4 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{cameraError}</span>
              </div>
            )}

            {/* Mode Segmented Selector (when not recording) */}
            {recordingState === 'idle' && (
              <div className="flex items-center justify-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl mb-4 max-w-md mx-auto w-full">
                <button
                  onClick={() => setMode('camera')}
                  className={`flex-1 py-1.5 px-2 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                    mode === 'camera'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Video className="w-3.5 h-3.5" />
                  <span>Cam + Mic</span>
                </button>

                <button
                  onClick={() => setMode('screen_cam')}
                  className={`flex-1 py-1.5 px-2 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                    mode === 'screen_cam'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Screen + Cam</span>
                </button>

                <button
                  onClick={() => setMode('screen_only')}
                  className={`flex-1 py-1.5 px-2 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                    mode === 'screen_only'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span>Screen Only</span>
                </button>

                <button
                  onClick={() => setMode('simulation')}
                  className={`flex-1 py-1.5 px-2 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                    mode === 'simulation'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Simulated</span>
                </button>
              </div>
            )}

            {/* Video Preview Frame */}
            <div className="relative flex-1 min-h-[300px] w-full bg-slate-900 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center shadow-inner">
              {recordingState === 'review' ? (
                /* Review Video Player */
                <div className="w-full h-full flex items-center justify-center bg-slate-950 relative">
                  {recordedBlobUrl && recordedBlobUrl.startsWith('blob:') ? (
                    <video
                      ref={reviewVideoRef}
                      src={recordedBlobUrl}
                      controls
                      autoPlay
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div className="text-center p-8">
                      <div className="w-16 h-16 rounded-full bg-emerald-600/20 text-emerald-400 flex items-center justify-center mx-auto mb-3">
                        <Check className="w-8 h-8" />
                      </div>
                      <h3 className="text-sm font-semibold text-slate-200">Video Standup Recorded!</h3>
                      <p className="text-xs text-slate-400 mt-1 max-w-sm">
                        Duration: {formatTimer(duration)}. Ready for team channel distribution with AI transcription.
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                /* Live Camera or Screen View */
                <div className="relative w-full h-full flex items-center justify-center bg-slate-950">
                  {mode === 'simulation' ? (
                    <div className="relative w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-950">
                      <div className="relative">
                        <img
                          src={currentUser.avatar}
                          alt={currentUser.name}
                          className="w-24 h-24 rounded-full border-4 border-indigo-500 shadow-2xl object-cover mb-4"
                        />
                        {recordingState === 'recording' && (
                          <div className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-rose-600 border-2 border-slate-950 animate-ping" />
                        )}
                      </div>
                      <h4 className="text-sm font-semibold text-slate-200">{currentUser.name}</h4>
                      <p className="text-xs text-slate-400">{currentUser.role} · {currentUser.city}</p>
                      <span className="mt-3 px-3 py-1 rounded-full text-[11px] bg-indigo-950/80 text-indigo-300 border border-indigo-800">
                        ⚡ Studio Simulator Mode Active
                      </span>
                    </div>
                  ) : (
                    <video
                      ref={liveVideoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover mirror"
                    />
                  )}

                  {/* Countdown overlay (3, 2, 1) */}
                  {recordingState === 'countdown' && (
                    <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-30">
                      <div className="w-24 h-24 rounded-full bg-indigo-600 text-white flex items-center justify-center text-5xl font-black shadow-2xl animate-pulse">
                        {countdown}
                      </div>
                    </div>
                  )}

                  {/* Live Recording Badge & Timer */}
                  {recordingState === 'recording' && (
                    <div className="absolute top-4 left-4 z-20 flex items-center gap-2 bg-slate-950/80 backdrop-blur px-3 py-1.5 rounded-full border border-slate-700">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping" />
                      <span className="text-xs font-mono font-bold text-rose-400">REC</span>
                      <span className="text-xs font-mono text-slate-200">{formatTimer(duration)}</span>
                    </div>
                  )}

                  {/* Microphone VU Level Meter */}
                  <div className="absolute bottom-4 left-4 z-20 flex items-center gap-2 bg-slate-950/80 backdrop-blur px-3 py-1.5 rounded-full border border-slate-700">
                    <Mic className="w-3.5 h-3.5 text-indigo-400" />
                    <div className="flex items-center gap-0.5 w-16 h-3">
                      {[1, 2, 3, 4, 5, 6, 7, 8].map(bar => {
                        const threshold = (bar / 8) * 100;
                        const active = micLevel >= threshold;
                        return (
                          <span
                            key={bar}
                            className={`flex-1 h-full rounded-sm transition-colors ${
                              active
                                ? bar > 6
                                  ? 'bg-rose-500'
                                  : bar > 4
                                  ? 'bg-amber-400'
                                  : 'bg-emerald-400'
                                : 'bg-slate-800'
                            }`}
                          />
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Controls Bar */}
            <div className="mt-4 flex items-center justify-between">
              {recordingState === 'idle' && (
                <div className="w-full flex items-center justify-center">
                  <button
                    onClick={startCountdown}
                    className="flex items-center gap-2 px-6 py-3 rounded-full bg-rose-600 hover:bg-rose-500 text-white font-semibold text-sm shadow-xl shadow-rose-900/30 hover:scale-105 active:scale-95 transition-all"
                  >
                    <span className="w-3 h-3 rounded-full bg-white" />
                    <span>Start Recording</span>
                  </button>
                </div>
              )}

              {recordingState === 'countdown' && (
                <div className="w-full text-center text-xs text-slate-400 font-mono">
                  Getting ready... {countdown}
                </div>
              )}

              {(recordingState === 'recording' || recordingState === 'paused') && (
                <div className="w-full flex items-center justify-center gap-4">
                  <button
                    onClick={pauseRecording}
                    className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
                  >
                    {recordingState === 'paused' ? 'Resume' : 'Pause'}
                  </button>

                  <button
                    onClick={finishRecording}
                    className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-lg transition-transform hover:scale-105"
                  >
                    <Square className="w-3.5 h-3.5 fill-current" />
                    <span>Finish Recording</span>
                  </button>

                  <button
                    onClick={handleRetake}
                    className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs font-medium transition-colors"
                  >
                    Cancel & Retake
                  </button>
                </div>
              )}

              {recordingState === 'review' && (
                <div className="w-full flex items-center justify-between gap-4">
                  <button
                    onClick={handleRetake}
                    className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Re-record</span>
                  </button>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={handlePublish}
                      className="flex items-center gap-2 px-6 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-900/30 transition-all hover:scale-105"
                    >
                      <Check className="w-4 h-4" />
                      <span>Publish to #{channels.find(c => c.id === channelId)?.name || 'channel'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Drawer: Teleprompter Notes (when recording) OR Metadata Details (when reviewing) */}
          {showTeleprompter && (
            <div className="w-80 bg-slate-950 border-l border-slate-800 flex flex-col overflow-y-auto p-4 text-xs">
              {recordingState === 'review' ? (
                /* Metadata form on review */
                <div className="space-y-4">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                      Standup Title
                    </label>
                    <input
                      type="text"
                      value={title}
                      onChange={e => setTitle(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                      Target Channel
                    </label>
                    <select
                      value={channelId}
                      onChange={e => setChannelId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    >
                      {channels.map(c => (
                        <option key={c.id} value={c.id}>
                          #{c.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="p-3 rounded-lg bg-indigo-950/40 border border-indigo-800/50 space-y-2">
                    <div className="flex items-center gap-1.5 text-indigo-300 font-semibold text-xs">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>AI Post-Processing</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      AsyncHub automatically transcribes audio, extracts timestamped action items, and generates cross-timezone summaries upon publish.
                    </p>
                  </div>
                </div>
              ) : (
                /* Teleprompter notes during recording */
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                      Standup Prompt Notes
                    </span>
                    <span className="text-[10px] text-slate-500">Edit anytime</span>
                  </div>

                  {/* Yesterday */}
                  <div>
                    <label className="block text-[11px] font-semibold text-emerald-400 mb-1 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      Yesterday (What you completed)
                    </label>
                    <textarea
                      rows={3}
                      value={teleprompterYesterday}
                      onChange={e => setTeleprompterYesterday(e.target.value)}
                      placeholder="Bullet 1&#10;Bullet 2"
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500 resize-none font-mono"
                    />
                  </div>

                  {/* Today */}
                  <div>
                    <label className="block text-[11px] font-semibold text-sky-400 mb-1 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                      Today (Primary focus)
                    </label>
                    <textarea
                      rows={3}
                      value={teleprompterToday}
                      onChange={e => setTeleprompterToday(e.target.value)}
                      placeholder="Bullet 1&#10;Bullet 2"
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-sky-500 resize-none font-mono"
                    />
                  </div>

                  {/* Blockers */}
                  <div>
                    <label className="block text-[11px] font-semibold text-rose-400 mb-1 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3 text-rose-400" />
                      Blockers / Dependencies
                    </label>
                    <textarea
                      rows={2}
                      value={teleprompterBlockers}
                      onChange={e => setTeleprompterBlockers(e.target.value)}
                      placeholder="None or list blockers..."
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-rose-500 resize-none font-mono"
                    />
                  </div>

                  <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400">
                    💡 Tip: Keep async standups under 2 minutes for maximum cross-timezone viewership.
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

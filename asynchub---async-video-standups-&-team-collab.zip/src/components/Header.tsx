import React from 'react';
import {
  Search,
  Video,
  Globe,
  SlidersHorizontal,
  ChevronDown,
  Sparkles,
} from 'lucide-react';
import { Channel } from '../types';

interface HeaderProps {
  channel: Channel;
  onOpenSearch: () => void;
  onOpenRecorder: () => void;
  viewMode: 'feed' | 'grid';
  onToggleViewMode: (mode: 'feed' | 'grid') => void;
}

export const Header: React.FC<HeaderProps> = ({
  channel,
  onOpenSearch,
  onOpenRecorder,
  viewMode,
  onToggleViewMode,
}) => {
  return (
    <header className="h-14 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md px-6 flex items-center justify-between gap-4 shrink-0">
      {/* Channel info */}
      <div className="flex items-center gap-3 min-w-0">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-slate-100 truncate">#{channel.name}</h2>
            <span className="text-[11px] text-slate-400 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded-full font-medium">
              {channel.cadence}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 truncate max-w-md hidden sm:block">
            {channel.description}
          </p>
        </div>
      </div>

      {/* Center / Right controls */}
      <div className="flex items-center gap-3">
        {/* Global Search Button with ⌘K badge */}
        <button
          onClick={onOpenSearch}
          className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700 transition-colors text-xs"
        >
          <Search className="w-3.5 h-3.5 text-indigo-400" />
          <span className="hidden md:inline">Search spoken words & transcripts...</span>
          <span className="md:hidden">Search</span>
          <kbd className="hidden md:inline-flex items-center px-1.5 py-0.5 text-[10px] font-mono font-medium text-slate-400 bg-slate-800/80 border border-slate-700/60 rounded">
            ⌘K
          </kbd>
        </button>

        {/* Distributed Team Timezone Overlap badge */}
        <div className="hidden lg:flex items-center gap-1.5 text-xs text-slate-400 bg-slate-900/60 border border-slate-800/70 px-2.5 py-1.5 rounded-xl">
          <Globe className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[11px]">4 Timezones Connected</span>
        </div>

        {/* Primary Record Standup Button */}
        <button
          onClick={onOpenRecorder}
          className="flex items-center gap-2 px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-900/25 transition-all hover:scale-105 active:scale-95 shrink-0"
        >
          <Video className="w-3.5 h-3.5 fill-current" />
          <span>Record Standup</span>
        </button>
      </div>
    </header>
  );
};

import React from 'react';
import {
  Video,
  Hash,
  Lock,
  AlertTriangle,
  Sparkles,
  Palette,
  Megaphone,
  CheckSquare,
  Clock,
  BarChart3,
  Layers,
  ChevronDown,
  User as UserIcon,
  Circle,
  TrendingUp,
} from 'lucide-react';
import { Channel, User } from '../types';

interface SidebarProps {
  channels: Channel[];
  selectedChannelId: string;
  onSelectChannel: (channelId: string) => void;
  teamMembers: User[];
  currentUser: User;
  activeFilter: 'all' | 'unwatched' | 'blockers' | 'my_videos';
  onSelectFilter: (filter: 'all' | 'unwatched' | 'blockers' | 'my_videos') => void;
  onOpenActionItems: () => void;
  onOpenTeamPulse: () => void;
  totalActionItemsCount: number;
  standupCheckinCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  channels,
  selectedChannelId,
  onSelectChannel,
  teamMembers,
  currentUser,
  activeFilter,
  onSelectFilter,
  onOpenActionItems,
  onOpenTeamPulse,
  totalActionItemsCount,
  standupCheckinCount,
}) => {
  const getChannelIcon = (name: string) => {
    switch (name) {
      case 'AlertTriangle':
        return <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />;
      case 'Palette':
        return <Palette className="w-3.5 h-3.5 text-purple-400" />;
      case 'Sparkles':
        return <Sparkles className="w-3.5 h-3.5 text-amber-400" />;
      case 'Megaphone':
        return <Megaphone className="w-3.5 h-3.5 text-blue-400" />;
      default:
        return <Hash className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const getTimezoneTime = (offsetHours: number) => {
    const d = new Date();
    const utc = d.getTime() + d.getTimezoneOffset() * 60000;
    const target = new Date(utc + 3600000 * offsetHours);
    return target.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  };

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800/80 flex flex-col h-full select-none shrink-0">
      {/* Workspace Switcher */}
      <div className="p-3 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-indigo-700 flex items-center justify-center text-white font-bold text-xs shadow-md">
            AS
          </div>
          <div>
            <h1 className="text-xs font-bold text-slate-100 flex items-center gap-1">
              AsyncHub
              <ChevronDown className="w-3 h-3 text-slate-500" />
            </h1>
            <p className="text-[10px] text-slate-400">Acme Distributed Team</p>
          </div>
        </div>
      </div>

      {/* Async Standup Progress Metric Widget */}
      <div className="p-3 border-b border-slate-800/60 bg-slate-900/40">
        <div className="flex items-center justify-between text-[11px] mb-1.5">
          <span className="font-semibold text-slate-300">Today&apos;s Standups</span>
          <span className="font-mono text-indigo-400 font-bold">
            {standupCheckinCount}/{teamMembers.length}
          </span>
        </div>
        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-indigo-500 rounded-full transition-all duration-500"
            style={{ width: `${(standupCheckinCount / teamMembers.length) * 100}%` }}
          />
        </div>
        <p className="text-[10px] text-slate-500 mt-1.5 flex items-center justify-between">
          <span>~3.8 hrs meetings saved this week</span>
        </p>
      </div>

      {/* Navigation Sections */}
      <div className="flex-1 overflow-y-auto p-3 space-y-5 text-xs">
        {/* Quick Views */}
        <div>
          <div className="px-2 mb-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Views
          </div>
          <div className="space-y-0.5">
            <button
              onClick={() => onSelectFilter('all')}
              className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeFilter === 'all'
                  ? 'bg-indigo-600/15 text-indigo-300'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center gap-2">
                <Layers className="w-3.5 h-3.5" />
                <span>All Standups</span>
              </div>
            </button>

            <button
              onClick={() => onSelectFilter('unwatched')}
              className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeFilter === 'unwatched'
                  ? 'bg-indigo-600/15 text-indigo-300'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center gap-2">
                <Circle className="w-3.5 h-3.5 text-indigo-400 fill-current" />
                <span>Unwatched</span>
              </div>
            </button>

            <button
              onClick={() => onSelectFilter('blockers')}
              className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeFilter === 'blockers'
                  ? 'bg-rose-950/40 text-rose-300'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                <span>Blocker Alerts</span>
              </div>
            </button>

            <button
              onClick={() => onSelectFilter('my_videos')}
              className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeFilter === 'my_videos'
                  ? 'bg-indigo-600/15 text-indigo-300'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center gap-2">
                <Video className="w-3.5 h-3.5" />
                <span>My Recordings</span>
              </div>
            </button>
          </div>
        </div>

        {/* Channels */}
        <div>
          <div className="px-2 mb-1 flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            <span>Standup Channels</span>
            <span className="font-mono text-slate-400">{channels.length}</span>
          </div>

          <div className="space-y-0.5">
            {channels.map(channel => {
              const isSelected = selectedChannelId === channel.id;
              return (
                <button
                  key={channel.id}
                  onClick={() => onSelectChannel(channel.id)}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    isSelected
                      ? 'bg-slate-800 text-slate-100 font-semibold shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    {getChannelIcon(channel.iconName)}
                    <span className="truncate">{channel.name}</span>
                  </div>

                  {channel.unreadCount && channel.unreadCount > 0 ? (
                    <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-indigo-600 text-white">
                      {channel.unreadCount}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </div>
        </div>

        {/* Global Distributed Team Members with Local Time */}
        <div>
          <div className="px-2 mb-1 flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            <span>Global Team Timezones</span>
          </div>

          <div className="space-y-1">
            {teamMembers.map(member => {
              const isMe = member.id === currentUser.id;
              return (
                <div
                  key={member.id}
                  className="flex items-center justify-between px-2 py-1.5 rounded-lg hover:bg-slate-900/50 text-[11px] text-slate-300"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="relative shrink-0">
                      <img
                        src={member.avatar}
                        alt={member.name}
                        className="w-5 h-5 rounded-full object-cover border border-slate-700"
                      />
                      <span
                        className={`absolute -bottom-0.5 -right-0.5 w-1.5 h-1.5 rounded-full ${
                          member.status === 'online'
                            ? 'bg-emerald-500'
                            : member.status === 'recording'
                            ? 'bg-rose-500 animate-pulse'
                            : member.status === 'focus'
                            ? 'bg-amber-500'
                            : 'bg-slate-500'
                        }`}
                      />
                    </div>
                    <span className="truncate">
                      {member.name.split(' ')[0]} {isMe && '(You)'}
                    </span>
                  </div>

                  <span className="font-mono text-[10px] text-slate-400 shrink-0">
                    {getTimezoneTime(member.timezoneOffset)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Action Items Hub & Team Pulse Buttons */}
        <div className="pt-2 border-t border-slate-800/80 space-y-1">
          <button
            onClick={onOpenActionItems}
            className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 text-xs font-medium"
          >
            <div className="flex items-center gap-2">
              <CheckSquare className="w-3.5 h-3.5 text-indigo-400" />
              <span>Action Items</span>
            </div>
            {totalActionItemsCount > 0 && (
              <span className="text-[10px] font-mono px-1.5 rounded bg-slate-800 text-slate-300">
                {totalActionItemsCount}
              </span>
            )}
          </button>

          <button
            onClick={onOpenTeamPulse}
            className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 text-xs font-medium"
          >
            <div className="flex items-center gap-2">
              <BarChart3 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Async Pulse & ROI</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-medium">94%</span>
          </button>
        </div>
      </div>

      {/* User profile footer */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/60 flex items-center justify-between">
        <div className="flex items-center gap-2 min-w-0">
          <div className="relative">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-7 h-7 rounded-full object-cover border border-indigo-500"
            />
            <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-500 border border-slate-950" />
          </div>
          <div className="truncate">
            <p className="text-xs font-semibold text-slate-200 truncate">{currentUser.name}</p>
            <p className="text-[10px] text-slate-400 truncate">{currentUser.city}</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

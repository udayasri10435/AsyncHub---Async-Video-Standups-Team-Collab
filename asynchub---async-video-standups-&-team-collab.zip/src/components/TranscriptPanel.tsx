import React, { useState } from 'react';
import { Search, Copy, Check, Clock, Edit2 } from 'lucide-react';
import { StandupVideo, TranscriptEntry } from '../types';

interface TranscriptPanelProps {
  video: StandupVideo;
  currentTime: number;
  onSeek: (time: number) => void;
  onUpdateTranscript?: (updatedTranscript: TranscriptEntry[]) => void;
}

export const TranscriptPanel: React.FC<TranscriptPanelProps> = ({
  video,
  currentTime,
  onSeek,
  onUpdateTranscript,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [copied, setCopied] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const filteredTranscript = video.transcript.filter(entry =>
    entry.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
    entry.speaker.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const copyFullTranscript = () => {
    const text = video.transcript
      .map(entry => `[${formatTime(entry.time)}] ${entry.speaker}: ${entry.text}`)
      .join('\n');
    navigator.clipboard?.writeText?.(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleStartEdit = (entry: TranscriptEntry) => {
    setEditingId(entry.id);
    setEditText(entry.text);
  };

  const handleSaveEdit = (id: string) => {
    if (onUpdateTranscript) {
      const updated = video.transcript.map(item =>
        item.id === id ? { ...item, text: editText.trim() } : item
      );
      onUpdateTranscript(updated);
    }
    setEditingId(null);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/60 rounded-xl border border-slate-800/80 overflow-hidden">
      {/* Header controls: Search & Copy */}
      <div className="p-3 border-b border-slate-800/80 flex items-center justify-between gap-2 bg-slate-900/80">
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search transcript..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 pl-8 pr-3 py-1.5 rounded-lg focus:outline-none focus:border-indigo-500 transition-colors"
          />
        </div>

        <button
          onClick={copyFullTranscript}
          title="Copy entire transcript"
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-400 hover:text-slate-200 bg-slate-800/60 hover:bg-slate-800 rounded-lg border border-slate-700/50 transition-colors shrink-0"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Copied' : 'Copy'}</span>
        </button>
      </div>

      {/* Transcript Line Items */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 divide-y divide-slate-800/40">
        {filteredTranscript.length === 0 ? (
          <div className="text-center py-10 text-slate-500 text-xs">
            No spoken phrases match &ldquo;{searchTerm}&rdquo;
          </div>
        ) : (
          filteredTranscript.map((entry, index) => {
            const nextEntry = video.transcript[index + 1];
            const isCurrent =
              currentTime >= entry.time && (!nextEntry || currentTime < nextEntry.time);

            return (
              <div
                key={entry.id}
                className={`pt-2 group flex flex-col gap-1 rounded-lg px-2 transition-all cursor-pointer ${
                  isCurrent
                    ? 'bg-indigo-950/40 border-l-2 border-indigo-500 pl-2.5 shadow-sm'
                    : 'hover:bg-slate-800/30'
                }`}
                onClick={() => onSeek(entry.time)}
              >
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-300">{entry.speaker}</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSeek(entry.time);
                      }}
                      className="flex items-center gap-1 font-mono text-indigo-400 hover:text-indigo-300 hover:underline"
                    >
                      <Clock className="w-3 h-3" />
                      {formatTime(entry.time)}
                    </button>
                  </div>

                  {/* Edit button */}
                  {onUpdateTranscript && editingId !== entry.id && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleStartEdit(entry);
                      }}
                      className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-slate-300 transition-opacity p-0.5"
                      title="Edit transcript line"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                  )}
                </div>

                {editingId === entry.id ? (
                  <div className="mt-1 flex items-center gap-2" onClick={e => e.stopPropagation()}>
                    <input
                      type="text"
                      value={editText}
                      onChange={e => setEditText(e.target.value)}
                      className="flex-1 bg-slate-950 border border-indigo-500 text-xs text-white px-2 py-1 rounded focus:outline-none"
                      autoFocus
                    />
                    <button
                      onClick={() => handleSaveEdit(entry.id)}
                      className="px-2 py-1 bg-indigo-600 text-white text-xs rounded hover:bg-indigo-500"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setEditingId(null)}
                      className="px-2 py-1 bg-slate-800 text-slate-300 text-xs rounded hover:bg-slate-700"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <p
                    className={`text-xs leading-relaxed transition-colors ${
                      isCurrent ? 'text-indigo-100 font-medium' : 'text-slate-300'
                    }`}
                  >
                    {highlightMatch(entry.text, searchTerm)}
                  </p>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

function highlightMatch(text: string, term: string) {
  if (!term.trim()) return text;
  const parts = text.split(new RegExp(`(${term})`, 'gi'));
  return (
    <>
      {parts.map((part, i) =>
        part.toLowerCase() === term.toLowerCase() ? (
          <mark key={i} className="bg-indigo-500/30 text-indigo-200 px-0.5 rounded font-medium">
            {part}
          </mark>
        ) : (
          part
        )
      )}
    </>
  );
}

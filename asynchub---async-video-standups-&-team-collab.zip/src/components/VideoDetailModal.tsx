import React, { useState, useEffect } from 'react';
import {
  X,
  FileText,
  Sparkles,
  MessageSquare,
  Clock,
  Eye,
  CheckCircle2,
  Calendar,
  Share2,
} from 'lucide-react';
import { StandupVideo, User, VideoReply, TranscriptEntry } from '../types';
import { VideoPlayer } from './VideoPlayer';
import { TranscriptPanel } from './TranscriptPanel';
import { SummaryPanel } from './SummaryPanel';
import { ThreadPanel } from './ThreadPanel';
import { QuickVideoReplyModal } from './QuickVideoReplyModal';

interface VideoDetailModalProps {
  video: StandupVideo | null;
  onClose: () => void;
  currentUser: User;
  initialSeekTime?: number;
  onAddReaction: (videoId: string, emoji: string, time: number) => void;
  onAddReply: (videoId: string, reply: VideoReply) => void;
  onToggleActionItem: (videoId: string, actionId: string) => void;
  onAddActionItem: (videoId: string, text: string, assignee?: string) => void;
  onUpdateTranscript: (videoId: string, transcript: TranscriptEntry[]) => void;
}

type TabType = 'transcript' | 'summary' | 'replies';

export const VideoDetailModal: React.FC<VideoDetailModalProps> = ({
  video,
  onClose,
  currentUser,
  initialSeekTime,
  onAddReaction,
  onAddReply,
  onToggleActionItem,
  onAddActionItem,
  onUpdateTranscript,
}) => {
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [seekToTime, setSeekToTime] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<TabType>('transcript');
  const [isQuickReplyOpen, setIsQuickReplyOpen] = useState<boolean>(false);
  const [replyTimestampRef, setReplyTimestampRef] = useState<number | undefined>(undefined);
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);

  useEffect(() => {
    if (typeof initialSeekTime === 'number') {
      setCurrentTime(initialSeekTime);
      setSeekToTime(initialSeekTime);
    } else {
      setCurrentTime(0);
      setSeekToTime(0);
    }
  }, [video?.id, initialSeekTime]);

  if (!video) return null;

  const handleSeek = (time: number) => {
    setCurrentTime(time);
    setSeekToTime(time);
  };

  const handleOpenQuickReply = (timeRef?: number) => {
    setReplyTimestampRef(timeRef);
    setIsQuickReplyOpen(true);
  };

  const handleTextReply = (text: string, timestampRef?: number) => {
    const newReply: VideoReply = {
      id: `rep-${Date.now()}`,
      videoId: video.id,
      author: currentUser,
      createdAt: new Date().toISOString(),
      type: 'text',
      content: text,
      timestampRef,
      reactions: {},
    };
    onAddReply(video.id, newReply);
  };

  const handleRegenerateAi = async () => {
    setIsGeneratingAi(true);
    try {
      const res = await fetch('/api/summarize-standup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: video.title,
          transcript: video.transcript,
          promptBullets: video.promptBullets,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.summary) {
          video.summary.keyTakeaways = data.summary.keyTakeaways || video.summary.keyTakeaways;
          if (data.summary.actionItems?.length) {
            video.summary.actionItems = data.summary.actionItems;
          }
        }
      }
    } catch (e) {
      console.warn('AI summary error, kept current summary');
    } finally {
      setTimeout(() => setIsGeneratingAi(false), 500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 md:p-6 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-6xl h-[92vh] max-h-[850px] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Top Header Bar */}
        <div className="px-5 py-3 border-b border-slate-800 bg-slate-950/50 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={video.author.avatar}
              alt={video.author.name}
              className="w-8 h-8 rounded-full object-cover border border-slate-700 shrink-0"
            />
            <div className="min-w-0">
              <h2 className="text-sm font-bold text-slate-100 truncate">{video.title}</h2>
              <div className="flex items-center gap-2 text-[11px] text-slate-400">
                <span className="font-semibold text-slate-300">{video.author.name}</span>
                <span>·</span>
                <span>{video.author.city}</span>
                <span>·</span>
                <span>#{video.channelId.replace('ch-', '')}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Main: Left Video Player & Right Tabs Panel */}
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
          {/* Left: Video Player Column */}
          <div className="w-full lg:w-7/12 p-4 flex flex-col justify-center bg-slate-950/60 overflow-y-auto">
            <VideoPlayer
              video={video}
              currentTime={currentTime}
              onTimeUpdate={setCurrentTime}
              onAddReaction={(emoji, time) => onAddReaction(video.id, emoji, time)}
              seekToTime={seekToTime}
            />

            {/* Quick Standup Note Pills under video */}
            <div className="mt-4 p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs">
              <div className="flex items-center justify-between text-slate-400 text-[11px] font-semibold mb-2 uppercase tracking-wider">
                <span>Standup Context</span>
                <span className="text-indigo-400">Click transcript below to jump</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                {video.promptBullets.today?.[0] && (
                  <div className="p-2 rounded-lg bg-sky-950/30 border border-sky-900/40 text-sky-200">
                    <span className="font-bold text-sky-400 block mb-0.5">Today&apos;s Focus:</span>
                    <span className="line-clamp-2">{video.promptBullets.today[0]}</span>
                  </div>
                )}
                {video.promptBullets.blockers?.[0] ? (
                  <div className="p-2 rounded-lg bg-rose-950/30 border border-rose-900/40 text-rose-200">
                    <span className="font-bold text-rose-400 block mb-0.5">Blocker:</span>
                    <span className="line-clamp-2">{video.promptBullets.blockers[0]}</span>
                  </div>
                ) : (
                  <div className="p-2 rounded-lg bg-emerald-950/30 border border-emerald-900/40 text-emerald-200">
                    <span className="font-bold text-emerald-400 block mb-0.5">Status:</span>
                    <span>No blockers reported. On track.</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right: Tabbed Details Column (Transcript / AI Summary / Replies) */}
          <div className="w-full lg:w-5/12 border-t lg:border-t-0 lg:border-l border-slate-800 flex flex-col bg-slate-900/40 overflow-hidden">
            {/* Tabs Header */}
            <div className="p-2 bg-slate-950/70 border-b border-slate-800 flex items-center gap-1">
              <button
                onClick={() => setActiveTab('transcript')}
                className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-1.5 ${
                  activeTab === 'transcript'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-indigo-400" />
                <span>Transcript ({video.transcript.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('summary')}
                className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-1.5 ${
                  activeTab === 'summary'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>AI Summary ({video.summary.actionItems.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('replies')}
                className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-1.5 ${
                  activeTab === 'replies'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
                <span>Replies ({video.replies.length})</span>
              </button>
            </div>

            {/* Tab Contents */}
            <div className="flex-1 overflow-hidden p-3">
              {activeTab === 'transcript' && (
                <TranscriptPanel
                  video={video}
                  currentTime={currentTime}
                  onSeek={handleSeek}
                  onUpdateTranscript={newTr => onUpdateTranscript(video.id, newTr)}
                />
              )}

              {activeTab === 'summary' && (
                <SummaryPanel
                  video={video}
                  onSeek={handleSeek}
                  onToggleActionItem={actId => onToggleActionItem(video.id, actId)}
                  onAddActionItem={(text, assignee) => onAddActionItem(video.id, text, assignee)}
                  onRegenerateAiSummary={handleRegenerateAi}
                  isGeneratingAi={isGeneratingAi}
                />
              )}

              {activeTab === 'replies' && (
                <ThreadPanel
                  video={video}
                  currentUser={currentUser}
                  currentTime={currentTime}
                  onSeek={handleSeek}
                  onAddTextReply={handleTextReply}
                  onOpenQuickVideoReply={handleOpenQuickReply}
                  onToggleReplyReaction={(replyId, emoji) => {
                    const reply = video.replies.find(r => r.id === replyId);
                    if (!reply) return;
                    if (!reply.reactions[emoji]) reply.reactions[emoji] = [];
                    const idx = reply.reactions[emoji].indexOf(currentUser.id);
                    if (idx > -1) {
                      reply.reactions[emoji].splice(idx, 1);
                      if (reply.reactions[emoji].length === 0) delete reply.reactions[emoji];
                    } else {
                      reply.reactions[emoji].push(currentUser.id);
                    }
                  }}
                />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Mini Video Reply Modal */}
      <QuickVideoReplyModal
        isOpen={isQuickReplyOpen}
        onClose={() => setIsQuickReplyOpen(false)}
        video={video}
        currentUser={currentUser}
        timestampRef={replyTimestampRef}
        onSaveReply={newReply => onAddReply(video.id, newReply)}
      />
    </div>
  );
};

import React from 'react';
import {
  Play,
  Clock,
  MessageSquare,
  AlertCircle,
  Eye,
  CheckCircle2,
  Calendar,
} from 'lucide-react';
import { StandupVideo, User } from '../types';

interface VideoCardProps {
  video: StandupVideo;
  currentUser: User;
  onSelect: (video: StandupVideo) => void;
  onReactionClick: (video: StandupVideo, emoji: string) => void;
}

export const VideoCard: React.FC<VideoCardProps> = ({
  video,
  currentUser,
  onSelect,
  onReactionClick,
}) => {
  const isViewed = video.viewedByUserIds?.includes(currentUser.id);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const formatRelativeTime = (isoString: string) => {
    const diffMs = Date.now() - new Date(isoString).getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    if (diffMins < 1) return 'just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${Math.floor(diffHours / 24)}d ago`;
  };

  return (
    <div
      onClick={() => onSelect(video)}
      className="group bg-slate-900/70 hover:bg-slate-900 border border-slate-800/80 hover:border-slate-700/80 rounded-2xl p-4 transition-all duration-200 cursor-pointer shadow-sm hover:shadow-xl flex flex-col md:flex-row gap-4"
    >
      {/* Video Thumbnail / Preview Aspect Box */}
      <div className="relative w-full md:w-64 aspect-video rounded-xl overflow-hidden bg-slate-950 border border-slate-800 shrink-0 flex items-center justify-center">
        <img
          src={video.thumbnailUrl}
          alt={video.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-80 group-hover:opacity-100"
        />

        {/* Dark overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

        {/* Play icon badge */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-10 h-10 rounded-full bg-indigo-600/90 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
            <Play className="w-5 h-5 ml-0.5 fill-current" />
          </div>
        </div>

        {/* Duration badge */}
        <div className="absolute bottom-2 right-2 bg-slate-950/90 text-slate-200 text-[11px] font-mono px-2 py-0.5 rounded backdrop-blur border border-slate-800">
          {formatTime(video.duration)}
        </div>

        {/* Video type indicator */}
        <div className="absolute top-2 left-2">
          {video.videoType === 'blocker' && (
            <span className="bg-rose-950/90 text-rose-300 border border-rose-800/60 text-[10px] font-semibold px-2 py-0.5 rounded backdrop-blur flex items-center gap-1">
              <AlertCircle className="w-3 h-3 text-rose-400" />
              Blocker
            </span>
          )}
          {video.videoType === 'daily_standup' && (
            <span className="bg-slate-900/90 text-slate-300 border border-slate-700/60 text-[10px] font-medium px-2 py-0.5 rounded backdrop-blur">
              ☀️ Standup
            </span>
          )}
          {video.videoType === 'design_critique' && (
            <span className="bg-purple-950/90 text-purple-300 border border-purple-800/60 text-[10px] font-medium px-2 py-0.5 rounded backdrop-blur">
              🎨 Critique
            </span>
          )}
        </div>
      </div>

      {/* Main Metadata & Standup Summary Content */}
      <div className="flex-1 flex flex-col justify-between min-w-0">
        <div>
          {/* Header Row: Author details & unread badge */}
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <div className="flex items-center gap-2 min-w-0">
              <div className="relative">
                <img
                  src={video.author.avatar}
                  alt={video.author.name}
                  className="w-7 h-7 rounded-full object-cover border border-slate-700"
                />
                <span
                  className={`absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full border border-slate-900 ${
                    video.author.status === 'online'
                      ? 'bg-emerald-500'
                      : video.author.status === 'focus'
                      ? 'bg-amber-500'
                      : 'bg-slate-500'
                  }`}
                />
              </div>

              <div className="truncate text-xs">
                <span className="font-semibold text-slate-200 mr-1.5">{video.author.name}</span>
                <span className="text-slate-400 text-[11px]">{video.author.city}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400 shrink-0">
              {!isViewed && (
                <span className="w-2 h-2 rounded-full bg-indigo-500" title="Unwatched standup" />
              )}
              <span className="text-[11px]">{formatRelativeTime(video.createdAt)}</span>
            </div>
          </div>

          {/* Title */}
          <h3 className="text-sm font-semibold text-slate-100 group-hover:text-indigo-400 transition-colors line-clamp-1 mb-2">
            {video.title}
          </h3>

          {/* Standup bullets preview */}
          <div className="space-y-1 text-xs text-slate-300 mb-3">
            {video.promptBullets.today?.[0] && (
              <p className="flex items-start gap-1.5 text-[11px] text-slate-300 line-clamp-1">
                <span className="text-sky-400 font-semibold shrink-0">Today:</span>
                <span className="truncate">{video.promptBullets.today[0]}</span>
              </p>
            )}
            {video.promptBullets.blockers?.[0] && (
              <p className="flex items-start gap-1.5 text-[11px] text-rose-300 line-clamp-1 font-medium">
                <span className="text-rose-400 font-semibold shrink-0">Blocker:</span>
                <span className="truncate">{video.promptBullets.blockers[0]}</span>
              </p>
            )}
          </div>
        </div>

        {/* Footer: Timeline Reactions, Replies & Views */}
        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2 text-xs text-slate-400 flex-wrap">
          {/* Reaction chips */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {video.timelineReactions.slice(0, 3).map(r => (
              <span
                key={r.id}
                className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-slate-800/70 border border-slate-700/60 text-[10px] text-slate-300"
              >
                <span>{r.emoji}</span>
                <span className="text-[9px] font-mono">{formatTime(r.time)}</span>
              </span>
            ))}
            {video.timelineReactions.length > 3 && (
              <span className="text-[10px] text-slate-500 font-mono">
                +{video.timelineReactions.length - 3}
              </span>
            )}
          </div>

          {/* Replies & Action items count */}
          <div className="flex items-center gap-3 text-[11px]">
            {video.summary.actionItems.length > 0 && (
              <div className="flex items-center gap-1 text-slate-400">
                <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />
                <span>{video.summary.actionItems.length} tasks</span>
              </div>
            )}

            <div className="flex items-center gap-1 text-slate-400">
              <MessageSquare className="w-3.5 h-3.5" />
              <span>{video.replies.length} replies</span>
            </div>

            <div className="flex items-center gap-1 text-slate-500">
              <Eye className="w-3.5 h-3.5" />
              <span>{video.viewsCount}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

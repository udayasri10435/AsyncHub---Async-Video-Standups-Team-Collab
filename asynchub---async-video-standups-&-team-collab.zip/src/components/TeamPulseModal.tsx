import React from 'react';
import {
  X,
  TrendingUp,
  Clock,
  Globe,
  Users,
  CheckCircle2,
  Calendar,
  Sparkles,
  Zap,
} from 'lucide-react';
import { User, StandupVideo } from '../types';

interface TeamPulseModalProps {
  isOpen: boolean;
  onClose: () => void;
  teamMembers: User[];
  videos: StandupVideo[];
}

export const TeamPulseModal: React.FC<TeamPulseModalProps> = ({
  isOpen,
  onClose,
  teamMembers,
  videos,
}) => {
  if (!isOpen) return null;

  const totalVideos = videos.length;
  const totalReplies = videos.reduce((sum, v) => sum + v.replies.length, 0);
  const totalActionItems = videos.reduce((sum, v) => sum + v.summary.actionItems.length, 0);
  const completedActionItems = videos.reduce(
    (sum, v) => sum + v.summary.actionItems.filter(a => a.done).length,
    0
  );

  // Estimation: Each async standup video replaces a 30-minute synchronous team meeting for 6 engineers
  const synchronousMeetingMinutesReplaced = totalVideos * 30 * teamMembers.length;
  const synchronousHoursSaved = (synchronousMeetingMinutesReplaced / 60).toFixed(1);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">Async Team Pulse & ROI</h3>
              <p className="text-xs text-slate-400">Distributed team efficiency & meeting reduction metrics</p>
            </div>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Metrics */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* Top highlight stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Hours Saved</span>
              <div className="text-2xl font-black text-emerald-400 font-mono mt-1">
                {synchronousHoursSaved}h
              </div>
              <span className="text-[10px] text-slate-500">vs live meetings</span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Standups Posted</span>
              <div className="text-2xl font-black text-indigo-400 font-mono mt-1">
                {totalVideos}
              </div>
              <span className="text-[10px] text-slate-500">100% on time</span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Async Replies</span>
              <div className="text-2xl font-black text-sky-400 font-mono mt-1">
                {totalReplies}
              </div>
              <span className="text-[10px] text-slate-500">Video & text</span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Tasks Completed</span>
              <div className="text-2xl font-black text-amber-400 font-mono mt-1">
                {completedActionItems}/{totalActionItems}
              </div>
              <span className="text-[10px] text-slate-500">Extracted by AI</span>
            </div>
          </div>

          {/* Timezone Distribution */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
              <span className="flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-indigo-400" />
                <span>Distributed Hub Locations</span>
              </span>
              <span className="text-slate-400 font-mono text-[11px]">5 Hubs · 4 Timezones</span>
            </div>

            <div className="space-y-2">
              {[
                { city: 'San Francisco (UTC-7)', count: 2, members: 'Alex, Sarah', percent: 33 },
                { city: 'London (UTC+1)', count: 1, members: 'Marcus', percent: 17 },
                { city: 'Berlin (UTC+2)', count: 1, members: 'Elena', percent: 17 },
                { city: 'Tokyo (UTC+9)', count: 1, members: 'Kenji', percent: 17 },
                { city: 'New York (UTC-4)', count: 1, members: 'Priya', percent: 17 },
              ].map(loc => (
                <div key={loc.city} className="flex items-center justify-between gap-3 text-[11px]">
                  <span className="text-slate-300 w-44 truncate">{loc.city}</span>
                  <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-500 rounded-full"
                      style={{ width: `${loc.percent * 2.5}%` }}
                    />
                  </div>
                  <span className="text-slate-400 font-mono w-24 text-right truncate">
                    {loc.members}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Best Practices */}
          <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-900/40 text-xs text-indigo-200 flex items-start gap-3">
            <Zap className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-indigo-100 mb-1">Async Best Practice Tip</h4>
              <p className="text-[11px] text-indigo-300 leading-relaxed">
                Distributed teammates prefer video standups under 90 seconds with clear bulleted notes.
                Use the built-in teleprompter to keep updates tight and action-oriented!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

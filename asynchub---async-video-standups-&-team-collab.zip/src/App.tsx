import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  INITIAL_CHANNELS,
  INITIAL_VIDEOS,
  TEAM_MEMBERS,
  CURRENT_USER,
} from './data/mockData';
import { StandupVideo, Channel, User, VideoReply, TranscriptEntry } from './types';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { VideoCard } from './components/VideoCard';
import { VideoDetailModal } from './components/VideoDetailModal';
import { RecorderModal } from './components/RecorderModal';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { ActionItemsDrawer } from './components/ActionItemsDrawer';
import { TeamPulseModal } from './components/TeamPulseModal';
import {
  Video,
  Plus,
  Sparkles,
  Layers,
  Filter,
  CheckCircle2,
  Calendar,
  AlertTriangle,
} from 'lucide-react';

export default function App() {
  const [channels] = useState<Channel[]>(INITIAL_CHANNELS);
  const [selectedChannelId, setSelectedChannelId] = useState<string>('ch-daily-standup');
  const [videos, setVideos] = useState<StandupVideo[]>(INITIAL_VIDEOS);
  const [currentUser] = useState<User>(CURRENT_USER);
  const [teamMembers] = useState<User[]>(TEAM_MEMBERS);

  // Modals & Drawers
  const [selectedVideo, setSelectedVideo] = useState<StandupVideo | null>(null);
  const [initialSeekTime, setInitialSeekTime] = useState<number | undefined>(undefined);
  const [isRecorderOpen, setIsRecorderOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isActionItemsOpen, setIsActionItemsOpen] = useState<boolean>(false);
  const [isTeamPulseOpen, setIsTeamPulseOpen] = useState<boolean>(false);

  // View state
  const [activeFilter, setActiveFilter] = useState<'all' | 'unwatched' | 'blockers' | 'my_videos'>('all');
  const [viewMode, setViewMode] = useState<'feed' | 'grid'>('feed');

  // Global keyboard shortcut for Search (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const currentChannel = useMemo(
    () => channels.find(c => c.id === selectedChannelId) || channels[0],
    [channels, selectedChannelId]
  );

  // Filter videos for the current channel and selected filter
  const filteredVideos = useMemo(() => {
    return videos.filter(video => {
      // Channel match
      if (video.channelId !== selectedChannelId) return false;

      // Filter match
      if (activeFilter === 'unwatched') {
        return !video.viewedByUserIds.includes(currentUser.id);
      }
      if (activeFilter === 'blockers') {
        return video.videoType === 'blocker' || video.promptBullets.blockers.length > 0;
      }
      if (activeFilter === 'my_videos') {
        return video.author.id === currentUser.id;
      }
      return true;
    });
  }, [videos, selectedChannelId, activeFilter, currentUser.id]);

  // Total action items across all videos
  const totalActionItemsCount = useMemo(() => {
    return videos.reduce((acc, v) => acc + v.summary.actionItems.filter(a => !a.done).length, 0);
  }, [videos]);

  // Number of team members who posted today
  const standupCheckinCount = useMemo(() => {
    const authors = new Set(
      videos.filter(v => v.videoType === 'daily_standup').map(v => v.author.id)
    );
    return authors.size;
  }, [videos]);

  // Open video detail and mark as read
  const handleSelectVideo = useCallback(
    (video: StandupVideo, seekTime?: number) => {
      // Mark as read
      setVideos(prev =>
        prev.map(v =>
          v.id === video.id
            ? {
                ...v,
                viewsCount: v.viewsCount + 1,
                viewedByUserIds: Array.from(new Set([...v.viewedByUserIds, currentUser.id])),
              }
            : v
        )
      );

      setSelectedVideo(video);
      setInitialSeekTime(seekTime);
    },
    [currentUser.id]
  );

  // Add timeline reaction
  const handleAddReaction = (videoId: string, emoji: string, time: number) => {
    const newReaction = {
      id: `re-${Date.now()}`,
      time,
      emoji,
      userId: currentUser.id,
      userName: currentUser.name,
      createdAt: 'just now',
    };

    setVideos(prev =>
      prev.map(v =>
        v.id === videoId
          ? {
              ...v,
              timelineReactions: [...v.timelineReactions, newReaction],
            }
          : v
      )
    );

    if (selectedVideo && selectedVideo.id === videoId) {
      setSelectedVideo(prev =>
        prev
          ? {
              ...prev,
              timelineReactions: [...prev.timelineReactions, newReaction],
            }
          : null
      );
    }
  };

  // Add threaded reply
  const handleAddReply = (videoId: string, reply: VideoReply) => {
    setVideos(prev =>
      prev.map(v =>
        v.id === videoId
          ? {
              ...v,
              replies: [...v.replies, reply],
            }
          : v
      )
    );

    if (selectedVideo && selectedVideo.id === videoId) {
      setSelectedVideo(prev =>
        prev
          ? {
              ...prev,
              replies: [...prev.replies, reply],
            }
          : null
      );
    }
  };

  // Toggle action item
  const handleToggleActionItem = (videoId: string, actionId: string) => {
    setVideos(prev =>
      prev.map(v => {
        if (v.id !== videoId) return v;
        const updatedItems = v.summary.actionItems.map(item =>
          item.id === actionId ? { ...item, done: !item.done } : item
        );
        return {
          ...v,
          summary: {
            ...v.summary,
            actionItems: updatedItems,
          },
        };
      })
    );

    if (selectedVideo && selectedVideo.id === videoId) {
      setSelectedVideo(prev =>
        prev
          ? {
              ...prev,
              summary: {
                ...prev.summary,
                actionItems: prev.summary.actionItems.map(item =>
                  item.id === actionId ? { ...item, done: !item.done } : item
                ),
              },
            }
          : null
      );
    }
  };

  // Add new action item
  const handleAddActionItem = (videoId: string, text: string, assigneeName?: string) => {
    const newItem = {
      id: `act-${Date.now()}`,
      text,
      assigneeName: assigneeName || currentUser.name,
      done: false,
      timestampRef: 0,
    };

    setVideos(prev =>
      prev.map(v => {
        if (v.id !== videoId) return v;
        return {
          ...v,
          summary: {
            ...v.summary,
            actionItems: [...v.summary.actionItems, newItem],
          },
        };
      })
    );

    if (selectedVideo && selectedVideo.id === videoId) {
      setSelectedVideo(prev =>
        prev
          ? {
              ...prev,
              summary: {
                ...prev.summary,
                actionItems: [...prev.summary.actionItems, newItem],
              },
            }
          : null
      );
    }
  };

  // Update transcript
  const handleUpdateTranscript = (videoId: string, updatedTranscript: TranscriptEntry[]) => {
    setVideos(prev =>
      prev.map(v =>
        v.id === videoId
          ? {
              ...v,
              transcript: updatedTranscript,
            }
          : v
      )
    );

    if (selectedVideo && selectedVideo.id === videoId) {
      setSelectedVideo(prev =>
        prev ? { ...prev, transcript: updatedTranscript } : null
      );
    }
  };

  // Save new recorded standup
  const handleSaveVideo = (newVideo: StandupVideo) => {
    setVideos(prev => [newVideo, ...prev]);
    setSelectedChannelId(newVideo.channelId);
    handleSelectVideo(newVideo);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100">
      {/* Slack-style Navigation Sidebar */}
      <Sidebar
        channels={channels}
        selectedChannelId={selectedChannelId}
        onSelectChannel={setSelectedChannelId}
        teamMembers={teamMembers}
        currentUser={currentUser}
        activeFilter={activeFilter}
        onSelectFilter={setActiveFilter}
        onOpenActionItems={() => setIsActionItemsOpen(true)}
        onOpenTeamPulse={() => setIsTeamPulseOpen(true)}
        totalActionItemsCount={totalActionItemsCount}
        standupCheckinCount={standupCheckinCount}
      />

      {/* Main Workspace Feed Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-slate-950">
        {/* Top Header */}
        <Header
          channel={currentChannel}
          onOpenSearch={() => setIsSearchOpen(true)}
          onOpenRecorder={() => setIsRecorderOpen(true)}
          viewMode={viewMode}
          onToggleViewMode={setViewMode}
        />

        {/* Feed Content Scroll Area */}
        <main className="flex-1 overflow-y-auto px-6 py-6">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Channel Async Standup Banner / Prompt Bar */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/30 to-slate-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
                    Async Standup Protocol
                  </span>
                  <span className="text-[11px] text-slate-400">· Keep it concise</span>
                </div>
                <p className="text-xs text-slate-300">
                  Record your 90-second update: 1. Yesterday&apos;s progress, 2. Today&apos;s focus, 3. Blockers.
                </p>
              </div>

              <button
                onClick={() => setIsRecorderOpen(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600/90 hover:bg-indigo-600 text-white text-xs font-semibold shadow transition-all hover:scale-105 shrink-0"
              >
                <Video className="w-3.5 h-3.5" />
                <span>Post Standup</span>
              </button>
            </div>

            {/* Standup Videos List */}
            {filteredVideos.length === 0 ? (
              <div className="py-20 text-center rounded-2xl border border-dashed border-slate-800 bg-slate-900/30 p-8">
                <Video className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <h3 className="text-sm font-bold text-slate-300">No standup recordings here yet</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto mb-4">
                  Be the first to record an asynchronous update for #{currentChannel.name}.
                </p>
                <button
                  onClick={() => setIsRecorderOpen(true)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-medium hover:bg-indigo-500 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>Record First Video</span>
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                  <span className="font-semibold uppercase tracking-wider text-[11px] text-slate-400">
                    Standup Timeline ({filteredVideos.length})
                  </span>
                  <span>Click any video to scrub, react, or view synced transcript</span>
                </div>

                {filteredVideos.map(video => (
                  <VideoCard
                    key={video.id}
                    video={video}
                    currentUser={currentUser}
                    onSelect={v => handleSelectVideo(v)}
                    onReactionClick={(v, emoji) => handleAddReaction(v.id, emoji, 0)}
                  />
                ))}
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Video Detail Modal with Player, Synced Transcript & Thread */}
      {selectedVideo && (
        <VideoDetailModal
          video={selectedVideo}
          onClose={() => setSelectedVideo(null)}
          currentUser={currentUser}
          initialSeekTime={initialSeekTime}
          onAddReaction={handleAddReaction}
          onAddReply={handleAddReply}
          onToggleActionItem={handleToggleActionItem}
          onAddActionItem={handleAddActionItem}
          onUpdateTranscript={handleUpdateTranscript}
        />
      )}

      {/* In-Browser Studio Recorder Modal (Loom style) */}
      <RecorderModal
        isOpen={isRecorderOpen}
        onClose={() => setIsRecorderOpen(false)}
        currentUser={currentUser}
        channels={channels}
        selectedChannelId={selectedChannelId}
        onSaveVideo={handleSaveVideo}
      />

      {/* Global Deep Transcript Search Modal (Cmd+K) */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        videos={videos}
        onSelectVideoAtTime={handleSelectVideo}
      />

      {/* Team Action Items Drawer */}
      <ActionItemsDrawer
        isOpen={isActionItemsOpen}
        onClose={() => setIsActionItemsOpen(false)}
        videos={videos}
        currentUser={currentUser}
        onToggleActionItem={handleToggleActionItem}
        onSelectVideoAtTime={handleSelectVideo}
      />

      {/* Team Async Pulse & ROI Modal */}
      <TeamPulseModal
        isOpen={isTeamPulseOpen}
        onClose={() => setIsTeamPulseOpen(false)}
        teamMembers={teamMembers}
        videos={videos}
      />
    </div>
  );
}

import { Channel, StandupVideo, User } from '../types';

export const CURRENT_USER: User = {
  id: 'usr-alex',
  name: 'Alex Morgan',
  handle: '@alexm',
  role: 'Staff Full-Stack Engineer',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
  timezone: 'America/Los_Angeles',
  timezoneOffset: -7,
  city: 'San Francisco, CA',
  status: 'online',
};

export const TEAM_MEMBERS: User[] = [
  CURRENT_USER,
  {
    id: 'usr-sarah',
    name: 'Sarah Chen',
    handle: '@sarahc',
    role: 'Frontend Architect',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=256&q=80',
    timezone: 'America/Los_Angeles',
    timezoneOffset: -7,
    city: 'San Francisco, CA',
    status: 'online',
  },
  {
    id: 'usr-marcus',
    name: 'Marcus Vance',
    handle: '@marcusv',
    role: 'Staff Backend Architect',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&q=80',
    timezone: 'Europe/London',
    timezoneOffset: 1,
    city: 'London, UK',
    status: 'focus',
  },
  {
    id: 'usr-elena',
    name: 'Elena Rostova',
    handle: '@elenar',
    role: 'Principal Product Designer',
    avatar: 'https://images.unsplash.com/photo-1534751516642-a171ed2a10d2?auto=format&fit=crop&w=256&q=80',
    timezone: 'Europe/Berlin',
    timezoneOffset: 2,
    city: 'Berlin, DE',
    status: 'online',
  },
  {
    id: 'usr-kenji',
    name: 'Kenji Takahashi',
    handle: '@kenjit',
    role: 'Platform & DevOps Lead',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=256&q=80',
    timezone: 'Asia/Tokyo',
    timezoneOffset: 9,
    city: 'Tokyo, JP',
    status: 'offline',
  },
  {
    id: 'usr-priya',
    name: 'Priya Patel',
    handle: '@priyap',
    role: 'Group Product Manager',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=256&q=80',
    timezone: 'America/New_York',
    timezoneOffset: -4,
    city: 'New York, NY',
    status: 'recording',
  },
];

export const INITIAL_CHANNELS: Channel[] = [
  {
    id: 'ch-daily-standup',
    name: 'daily-standup',
    slug: 'daily-standup',
    description: 'Daily async video standups for the distributed engineering team',
    iconName: 'Video',
    isPrivate: false,
    memberCount: 14,
    cadence: 'Daily (9 AM local)',
    unreadCount: 2,
  },
  {
    id: 'ch-product-design',
    name: 'product-and-design',
    slug: 'product-and-design',
    description: 'Async design reviews, prototype walkthroughs, and UI feedback',
    iconName: 'Palette',
    isPrivate: false,
    memberCount: 8,
    cadence: 'Twice weekly',
    unreadCount: 1,
  },
  {
    id: 'ch-engineering-blockers',
    name: 'engineering-blockers',
    slug: 'engineering-blockers',
    description: 'Urgent async alerts for blocking issues needing team unblocking',
    iconName: 'AlertTriangle',
    isPrivate: false,
    memberCount: 12,
    cadence: 'As needed',
    unreadCount: 0,
  },
  {
    id: 'ch-sprint-demos',
    name: 'sprint-demos',
    slug: 'sprint-demos',
    description: 'Quick 2-minute video showcases of shipped customer features',
    iconName: 'Sparkles',
    isPrivate: false,
    memberCount: 22,
    cadence: 'Weekly review',
    unreadCount: 3,
  },
  {
    id: 'ch-announcements',
    name: 'team-announcements',
    slug: 'team-announcements',
    description: 'Company-wide async briefings and leadership memos',
    iconName: 'Megaphone',
    isPrivate: false,
    memberCount: 45,
    cadence: 'As needed',
    unreadCount: 0,
  },
];

export const INITIAL_VIDEOS: StandupVideo[] = [
  {
    id: 'vid-sarah-standup-1',
    title: 'Checkout Flow Redesign & Safari ApplePay Drawer Fix',
    description: 'Walkthrough of the revised payment drawer UX and bug fix for Safari iOS WebKit rendering.',
    channelId: 'ch-daily-standup',
    author: TEAM_MEMBERS[1], // Sarah Chen
    createdAt: new Date(Date.now() - 1000 * 60 * 35).toISOString(), // 35 min ago
    duration: 84, // 1m 24s
    videoUrl: 'sample://checkout-redesign',
    thumbnailUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80',
    videoType: 'daily_standup',
    promptBullets: {
      yesterday: [
        'Finished checkout sheet animation and touch-drag dismissal on mobile',
        'Refactored cart calculation hooks to eliminate redundant re-renders',
      ],
      today: [
        'Testing ApplePay single-tap payment integration in staging sandbox',
        'Pairing with Marcus on webhook idempotency key validation',
      ],
      blockers: [
        'Awaiting Apple Sandbox merchant certificate approval from security ops',
      ],
    },
    transcript: [
      { id: 'tr-1', time: 0, speaker: 'Sarah Chen', text: 'Hey team, quick Tuesday morning update on checkout flow redesign.' },
      { id: 'tr-2', time: 8, speaker: 'Sarah Chen', text: 'Yesterday I finished implementing the smooth pull-down drawer on iOS safari.' },
      { id: 'tr-3', time: 19, speaker: 'Sarah Chen', text: 'We had that flickering issue when switching payment methods, but moving state into a persistent context solved it.' },
      { id: 'tr-4', time: 32, speaker: 'Sarah Chen', text: 'Today my primary focus is wiring up the ApplePay one-touch tokenization pipeline.' },
      { id: 'tr-5', time: 47, speaker: 'Sarah Chen', text: 'The only blocker right now is the renewed Apple Sandbox merchant certificate in 1Password.' },
      { id: 'tr-6', time: 61, speaker: 'Sarah Chen', text: 'Marcus, if you have 10 minutes later, lets verify the webhook idempotency contract.' },
      { id: 'tr-7', time: 74, speaker: 'Sarah Chen', text: 'Ill leave a thread link below with the staging URL for anyone to test.' },
    ],
    summary: {
      keyTakeaways: [
        'Mobile checkout bottom sheet flicker on iOS Safari resolved.',
        'ApplePay one-touch sandbox integration underway.',
        'Staging URL available for async testing.',
      ],
      actionItems: [
        { id: 'act-1', text: 'Test ApplePay checkout sheet on iOS staging device', assigneeName: 'Sarah Chen', done: true, timestampRef: 19 },
        { id: 'act-2', text: 'Review idempotency key validation on payment webhooks', assigneeName: 'Marcus Vance', done: false, timestampRef: 61 },
        { id: 'act-3', text: 'Refresh Apple Sandbox certificate credentials in 1Password', assigneeName: 'Kenji Takahashi', done: false, timestampRef: 47 },
      ],
      blockers: [
        'Apple Sandbox merchant certificate verification pending ops approval',
      ],
      standupBullets: {
        yesterday: ['Fixed iOS Safari drawer flicker', 'Refactored cart calculation hooks'],
        today: ['Wiring ApplePay one-touch tokens', 'Sync with Marcus on webhook idempotency'],
        blockers: ['Apple Sandbox merchant certificate needed'],
      },
    },
    timelineReactions: [
      { id: 're-1', time: 12, emoji: '🔥', userId: 'usr-alex', userName: 'Alex Morgan', createdAt: '10m ago' },
      { id: 're-2', time: 48, emoji: '👀', userId: 'usr-marcus', userName: 'Marcus Vance', createdAt: '8m ago' },
      { id: 're-3', time: 63, emoji: '👍', userId: 'usr-marcus', userName: 'Marcus Vance', createdAt: '5m ago' },
      { id: 're-4', time: 76, emoji: '🚀', userId: 'usr-priya', userName: 'Priya Patel', createdAt: '2m ago' },
    ],
    replies: [
      {
        id: 'rep-1',
        videoId: 'vid-sarah-standup-1',
        author: TEAM_MEMBERS[2], // Marcus
        createdAt: new Date(Date.now() - 1000 * 60 * 20).toISOString(),
        type: 'text',
        content: 'Certificate has been refreshed in 1Password under `Eng-Sandbox-Keys`! Webhooks payload is ready for your test token.',
        timestampRef: 47,
        reactions: { '🙌': ['usr-sarah', 'usr-alex'] },
      },
      {
        id: 'rep-2',
        videoId: 'vid-sarah-standup-1',
        author: TEAM_MEMBERS[4], // Kenji
        createdAt: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
        type: 'audio',
        audioUrl: 'sample://audio-kenji-reply',
        duration: 22,
        content: 'Voice note: Double checked the firewall rules for Apple sandbox endpoints. You are green to go.',
        timestampRef: 52,
        reactions: { '💯': ['usr-sarah'] },
      },
    ],
    viewsCount: 18,
    viewedByUserIds: ['usr-alex', 'usr-marcus', 'usr-priya', 'usr-kenji'],
    tags: ['Checkout', 'iOS Safari', 'ApplePay', 'Frontend'],
  },
  {
    id: 'vid-marcus-standup-2',
    title: 'PostgreSQL Connection Pooling Spike & Redis Cache Tuning',
    description: 'Deep dive into eliminating peak-traffic database connection timeouts using PgBouncer and tiered cache TTLs.',
    channelId: 'ch-daily-standup',
    author: TEAM_MEMBERS[2], // Marcus Vance
    createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(), // 2 hrs ago
    duration: 110, // 1m 50s
    videoUrl: 'sample://pg-connection-pooling',
    thumbnailUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80',
    videoType: 'daily_standup',
    promptBullets: {
      yesterday: [
        'Diagnosed 504 gateway timeout incidents during European peak traffic',
        'Benchmarked PgBouncer transaction-mode connection pool in staging',
      ],
      today: [
        'Roll out connection pool size adjustments to Frankfurt and London clusters',
        'Implement 90-second query circuit breaker to protect primary read replica',
      ],
      blockers: [
        'Need 30-minute change window confirmation from DevOps before applying RDS parameter group',
      ],
    },
    transcript: [
      { id: 'tr-201', time: 0, speaker: 'Marcus Vance', text: 'Good morning everyone from London. Heres the backend infra update.' },
      { id: 'tr-202', time: 10, speaker: 'Marcus Vance', text: 'Yesterday we pinpointed the transient 504 timeouts to connection pool starvation on our primary PostgreSQL instance.' },
      { id: 'tr-203', time: 26, speaker: 'Marcus Vance', text: 'Under synthetic load of 15,000 req/sec, switching to transaction pooling cut latency p99 from 480ms down to 32ms.' },
      { id: 'tr-204', time: 48, speaker: 'Marcus Vance', text: 'Today I am preparing the blue-green migration plan for the European clusters.' },
      { id: 'tr-205', time: 65, speaker: 'Marcus Vance', text: 'Kenji, I put a pull request in for the Terraform RDS parameter group changes.' },
      { id: 'tr-206', time: 82, speaker: 'Marcus Vance', text: 'No hard blockers, just need Terraform review so we can apply during low traffic window.' },
      { id: 'tr-207', time: 98, speaker: 'Marcus Vance', text: 'Catch you all on the threads, cheers.' },
    ],
    summary: {
      keyTakeaways: [
        'Identified root cause of 504 errors as connection pool exhaustion.',
        'PgBouncer transaction mode reduced p99 latency by 93% in staging.',
        'Blue-green migration ready for European RDS clusters.',
      ],
      actionItems: [
        { id: 'act-21', text: 'Review Terraform PR #482 for RDS parameter group', assigneeName: 'Kenji Takahashi', done: false, timestampRef: 65 },
        { id: 'act-22', text: 'Schedule 30-min low-traffic maintenance window', assigneeName: 'Marcus Vance', done: true, timestampRef: 82 },
      ],
      blockers: [
        'Pending peer approval on Terraform infrastructure changes',
      ],
    },
    timelineReactions: [
      { id: 're-201', time: 30, emoji: '⚡', userId: 'usr-alex', userName: 'Alex Morgan', createdAt: '1h ago' },
      { id: 're-202', time: 35, emoji: '🔥', userId: 'usr-kenji', userName: 'Kenji Takahashi', createdAt: '1h ago' },
      { id: 're-203', time: 70, emoji: '✅', userId: 'usr-kenji', userName: 'Kenji Takahashi', createdAt: '50m ago' },
    ],
    replies: [
      {
        id: 'rep-201',
        videoId: 'vid-marcus-standup-2',
        author: TEAM_MEMBERS[4], // Kenji
        createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
        type: 'text',
        content: 'Approved PR #482! Terraform plan looks clean with zero downtime expected. We can execute at 14:00 UTC.',
        timestampRef: 65,
        reactions: { '🎉': ['usr-marcus'] },
      },
    ],
    viewsCount: 24,
    viewedByUserIds: ['usr-alex', 'usr-sarah', 'usr-kenji', 'usr-priya'],
    tags: ['PostgreSQL', 'Infra', 'Performance', 'Redis'],
  },
  {
    id: 'vid-elena-design-3',
    title: 'Figma Review: Async Video Timeline Annotations & Micro-Reactions',
    description: 'Design walk-through of the scrubber waveform UI, floating emoji badges, and teleprompter overlay.',
    channelId: 'ch-product-design',
    author: TEAM_MEMBERS[3], // Elena Rostova
    createdAt: new Date(Date.now() - 1000 * 60 * 240).toISOString(), // 4 hrs ago
    duration: 96, // 1m 36s
    videoUrl: 'sample://figma-annotations-ux',
    thumbnailUrl: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?auto=format&fit=crop&w=800&q=80',
    videoType: 'design_critique',
    promptBullets: {
      yesterday: [
        'Designed timestamped reaction markers on timeline scrubber',
        'Prototyped teleprompter drawer with variable scroll speed',
      ],
      today: [
        'Gathering team feedback on the unified thread panel and video reply recorder',
        'Creating token spec for dark mode contrast compliance',
      ],
      blockers: [
        'Need input from Alex on whether canvas-based webcam bubbles support rounded corners seamlessly in Chrome and Safari',
      ],
    },
    transcript: [
      { id: 'tr-301', time: 0, speaker: 'Elena Rostova', text: 'Hi team! Excited to share the design specs for our async video player upgrades.' },
      { id: 'tr-302', time: 14, speaker: 'Elena Rostova', text: 'Notice how when you scrub the timeline, small emoji badges appear at the exact seconds teammates reacted.' },
      { id: 'tr-303', time: 32, speaker: 'Elena Rostova', text: 'Hovering on any dot previews the comment and author without interrupting playback.' },
      { id: 'tr-304', time: 51, speaker: 'Elena Rostova', text: 'For the recording studio, we added a teleprompter sidebar with Yesterday/Today/Blocker templates.' },
      { id: 'tr-305', time: 70, speaker: 'Elena Rostova', text: 'Check the Figma link in description. Would love thoughts from Alex and Sarah on engineering feasibility.' },
      { id: 'tr-306', time: 88, speaker: 'Elena Rostova', text: 'Thanks everyone, excited to see this in production!' },
    ],
    summary: {
      keyTakeaways: [
        'Timeline reactions with hover preview keep playback uninterrupted.',
        'Teleprompter notes provide structured standup templates.',
        'Zero-clutter design adheres to WCAG AA contrast standards.',
      ],
      actionItems: [
        { id: 'act-301', text: 'Review Figma component tokens for timeline scrubber', assigneeName: 'Alex Morgan', done: true, timestampRef: 70 },
        { id: 'act-302', text: 'Verify canvas circular clipping support across mobile browsers', assigneeName: 'Sarah Chen', done: false, timestampRef: 51 },
      ],
      blockers: [
        'Confirming canvas video compositor performance with WebCam + Screen share',
      ],
    },
    timelineReactions: [
      { id: 're-301', time: 16, emoji: '💡', userId: 'usr-alex', userName: 'Alex Morgan', createdAt: '3h ago' },
      { id: 're-302', time: 34, emoji: '❤️', userId: 'usr-priya', userName: 'Priya Patel', createdAt: '2h ago' },
      { id: 're-303', time: 54, emoji: '🚀', userId: 'usr-sarah', userName: 'Sarah Chen', createdAt: '2h ago' },
    ],
    replies: [
      {
        id: 'rep-301',
        videoId: 'vid-elena-design-3',
        author: CURRENT_USER,
        createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
        type: 'text',
        content: 'Canvas clipping `ctx.arc()` + `ctx.clip()` works flawlessly in both WebKit and Blink engines at 60fps! Built a prototype and it is buttery smooth.',
        timestampRef: 51,
        reactions: { '🙌': ['usr-elena'], '🔥': ['usr-priya'] },
      },
    ],
    viewsCount: 31,
    viewedByUserIds: ['usr-alex', 'usr-sarah', 'usr-marcus', 'usr-priya', 'usr-kenji'],
    tags: ['Design', 'Figma', 'UI/UX', 'VideoPlayer'],
  },
  {
    id: 'vid-priya-roadmap-4',
    title: 'Q3 Async Standup Metrics & Customer Pilot Kickoff',
    description: 'Weekly product overview on pilot cohort metrics: 4.8 hours saved per engineer/week since transitioning to async video standups.',
    channelId: 'ch-sprint-demos',
    author: TEAM_MEMBERS[5], // Priya Patel
    createdAt: new Date(Date.now() - 1000 * 60 * 600).toISOString(), // 10 hrs ago
    duration: 125, // 2m 05s
    videoUrl: 'sample://q3-metrics-kickoff',
    thumbnailUrl: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=800&q=80',
    videoType: 'announcement',
    promptBullets: {
      yesterday: [
        'Analyzed pilot team engagement data across our 8 early adopter enterprise accounts',
        'Synthesized feedback on threaded video replies vs pure text comments',
      ],
      today: [
        'Launching onboarding checklist for 4 new distributed engineering teams joining tomorrow',
        'Coordinating with Alex on deep transcript search indexing demo',
      ],
      blockers: [
        'None! Momentum is tremendous.',
      ],
    },
    transcript: [
      { id: 'tr-401', time: 0, speaker: 'Priya Patel', text: 'Hey team, exciting news to share from our Q3 async collaboration pilot program.' },
      { id: 'tr-402', time: 18, speaker: 'Priya Patel', text: 'Over the last 30 days across 8 distributed engineering teams, we eliminated 142 hours of synchronous morning standups.' },
      { id: 'tr-403', time: 38, speaker: 'Priya Patel', text: 'Engineers reported an average of 4.8 extra hours of uninterrupted deep focus work per week.' },
      { id: 'tr-404', time: 58, speaker: 'Priya Patel', text: 'The number one requested capability was deep transcript search, so people across timezones can find exact topics without watching 5-minute clips.' },
      { id: 'tr-405', time: 82, speaker: 'Priya Patel', text: 'Alex and Sarahs work on instant transcript jump has been highlighted as the killer feature.' },
      { id: 'tr-406', time: 104, speaker: 'Priya Patel', text: 'Big shoutout to everyone. Keep the async momentum rolling!' },
    ],
    summary: {
      keyTakeaways: [
        '142 hours of live meetings replaced with async video standups in pilot.',
        'Engineers gained 4.8 hours of uninterrupted focus time per week.',
        'Deep transcript search is the most loved feature for cross-timezone collaboration.',
      ],
      actionItems: [
        { id: 'act-401', text: 'Share customer pilot testimonials with marketing', assigneeName: 'Priya Patel', done: true, timestampRef: 38 },
        { id: 'act-402', text: 'Ensure transcript search ranks exact phrase matches highest', assigneeName: 'Alex Morgan', done: false, timestampRef: 82 },
      ],
      blockers: [],
    },
    timelineReactions: [
      { id: 're-401', time: 20, emoji: '🎉', userId: 'usr-alex', userName: 'Alex Morgan', createdAt: '8h ago' },
      { id: 're-402', time: 40, emoji: '🚀', userId: 'usr-marcus', userName: 'Marcus Vance', createdAt: '8h ago' },
      { id: 're-403', time: 85, emoji: '❤️', userId: 'usr-sarah', userName: 'Sarah Chen', createdAt: '7h ago' },
    ],
    replies: [
      {
        id: 'rep-401',
        videoId: 'vid-priya-roadmap-4',
        author: TEAM_MEMBERS[1], // Sarah
        createdAt: new Date(Date.now() - 1000 * 60 * 480).toISOString(),
        type: 'text',
        content: '4.8 hours of focus time returned to engineers is incredible. The async lifestyle is so much better for our European and Asian teammates!',
        timestampRef: 38,
        reactions: { '💯': ['usr-priya', 'usr-marcus', 'usr-kenji'] },
      },
    ],
    viewsCount: 42,
    viewedByUserIds: ['usr-alex', 'usr-sarah', 'usr-marcus', 'usr-elena', 'usr-kenji'],
    tags: ['Roadmap', 'Metrics', 'AsyncCulture', 'Milestone'],
  },
  {
    id: 'vid-kenji-devops-5',
    title: 'Kubernetes 1.32 Staging Rollout & Canary Health Checks',
    description: 'Screen-recording walkthrough of our zero-downtime k8s control plane upgrade and automated canary rollbacks.',
    channelId: 'ch-daily-standup',
    author: TEAM_MEMBERS[4], // Kenji Takahashi
    createdAt: new Date(Date.now() - 1000 * 60 * 750).toISOString(), // 12 hrs ago
    duration: 78, // 1m 18s
    videoUrl: 'sample://k8s-rollout',
    thumbnailUrl: 'https://images.unsplash.com/photo-1667372393119-3d4c48d07fc9?auto=format&fit=crop&w=800&q=80',
    videoType: 'feature_demo',
    promptBullets: {
      yesterday: [
        'Executed control plane upgrade on staging cluster to Kubernetes 1.32',
        'Validated Istio service mesh mTLS traffic and Envoy proxy sidecars',
      ],
      today: [
        'Deploying new Prometheus alerting rules for memory leak detection',
        'Reviewing backend PR from Marcus on PostgreSQL pool adjustments',
      ],
      blockers: [
        'None. All staging canary metrics are 100% green.',
      ],
    },
    transcript: [
      { id: 'tr-501', time: 0, speaker: 'Kenji Takahashi', text: 'Konbanwa from Tokyo! Here is a 1-minute demo of the Kubernetes 1.32 staging rollout.' },
      { id: 'tr-502', time: 14, speaker: 'Kenji Takahashi', text: 'Notice on my terminal screen how the worker nodes were cordoned and drained sequentially.' },
      { id: 'tr-503', time: 30, speaker: 'Kenji Takahashi', text: 'All traffic was routed to the healthy standby replicas with zero dropped HTTP requests.' },
      { id: 'tr-504', time: 48, speaker: 'Kenji Takahashi', text: 'Our automated canary verified error rates remained below 0.001% throughout the 15-minute rollout.' },
      { id: 'tr-505', time: 64, speaker: 'Kenji Takahashi', text: 'Production rollout is scheduled for Thursday night during the Asia-Pacific maintenance window.' },
    ],
    summary: {
      keyTakeaways: [
        'Kubernetes 1.32 control plane and worker nodes upgraded on staging.',
        'Zero HTTP request drop during node drain procedure.',
        'Production rollout planned for Thursday maintenance window.',
      ],
      actionItems: [
        { id: 'act-501', text: 'Monitor staging Grafana dashboard for next 24 hours', assigneeName: 'Kenji Takahashi', done: true, timestampRef: 48 },
        { id: 'act-502', text: 'Confirm staging backend smoke test with Marcus', assigneeName: 'Marcus Vance', done: true, timestampRef: 64 },
      ],
      blockers: [],
    },
    timelineReactions: [
      { id: 're-501', time: 32, emoji: '🔥', userId: 'usr-marcus', userName: 'Marcus Vance', createdAt: '11h ago' },
      { id: 're-502', time: 50, emoji: '👏', userId: 'usr-alex', userName: 'Alex Morgan', createdAt: '10h ago' },
    ],
    replies: [
      {
        id: 'rep-501',
        videoId: 'vid-kenji-devops-5',
        author: TEAM_MEMBERS[2], // Marcus
        createdAt: new Date(Date.now() - 1000 * 60 * 680).toISOString(),
        type: 'text',
        content: 'Zero dropped requests during a minor k8s upgrade is top tier engineering. Staging smoke tests passed on my side!',
        timestampRef: 30,
        reactions: { '🍻': ['usr-kenji'] },
      },
    ],
    viewsCount: 29,
    viewedByUserIds: ['usr-alex', 'usr-marcus', 'usr-sarah'],
    tags: ['Kubernetes', 'DevOps', 'Infrastructure', 'Canary'],
  },
];

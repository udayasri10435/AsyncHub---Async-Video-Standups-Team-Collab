import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = 3000;

app.use(express.json());

// API route to summarize standup and extract action items
app.post('/api/summarize-standup', async (req, res) => {
  try {
    const { title, transcript, promptBullets } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      // Heuristic fallback when user hasn't configured GEMINI_API_KEY
      return res.json({
        summary: {
          keyTakeaways: [
            `Progress completed on core tasks in "${title}".`,
            `Synchronized key deliverables with team dependencies.`,
            `Next milestones scheduled for async follow-up.`
          ],
          actionItems: [
            { id: 'act-ai-1', text: 'Verify staging deployment and notify channel', assigneeName: 'Team', done: false, timestampRef: 15 },
            { id: 'act-ai-2', text: 'Follow up on dependencies and blocker unblocking', assigneeName: 'Lead', done: false, timestampRef: 30 }
          ],
          blockers: promptBullets?.blockers?.length ? promptBullets.blockers : []
        }
      });
    }

    const ai = new GoogleGenAI({ apiKey });
    const prompt = `You are an AI assistant for AsyncHub, an asynchronous video standup workspace for distributed engineering teams.
Analyze this standup recording titled "${title}".

Transcript entries:
${JSON.stringify(transcript, null, 2)}

Standup notes:
${JSON.stringify(promptBullets, null, 2)}

Generate a clean, structured JSON object:
{
  "keyTakeaways": ["concise sentence 1", "concise sentence 2", "concise sentence 3"],
  "actionItems": [
    {
      "id": "act-1",
      "text": "specific actionable task with owner if mentioned",
      "assigneeName": "name of person or Team",
      "done": false,
      "timestampRef": 15
    }
  ],
  "blockers": ["blocker 1 if any"]
}
Only output valid JSON.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ summary: parsed });
  } catch (err: any) {
    console.error('Gemini error:', err);
    return res.status(500).json({ error: err.message });
  }
});

// Mount Vite or serve static
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (isProd) {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`AsyncHub Server running on http://0.0.0.0:${port}`);
  });
}

startServer();
